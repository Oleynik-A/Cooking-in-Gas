/*

"Imitation is the sincerest form of flattery" - Charles Caleb Colton

*/
const SHOPIFY_CHECKOUT_URL_REGEX = new RegExp("^https?://.+?/\\d+?/checkouts/\\w+?(?:$|\\?|/)", "i");
const ADIDAS_YS_PAYMENT_PAGE_REGEX = new RegExp("^https?://(?:www.)?(?:adidas|yeezysupply).+?/(?:delivery|payment|COShipping-Show|COSummary2-Start).*", "i");
const OFFWHITE_PAYMENT_PAGE_REGEX = new RegExp("^https?://(?:www.)?off---white.com/.+?/checkout/payment.*", "i");
const FOOTSITE_PAYMENT_PAGE_REGEX = new RegExp("^https?://(?:www.)?(?:footlocker|champssports|footaction|eastbay).+?/checkout.*", "i");
const FOOTSITE_EU_REGEX = new RegExp("^https?://(?:www.)?(?:footlocker).+?/INTERSHOP.*", "i");
const GLOBAL_E_PAGE_REGEX = new RegExp("^https?://webservices.global-e.com/Checkout/v2/.*", "i");
const ADD_LISTENER = "addListener";
const mutationObserver = new MutationObserver(mutationCallback);

var booleanMapDefault = new Map();
booleanMapDefault.set(ADD_LISTENER, true);

var href = getVal(window.location.href);
var items = [];

if (isSiteIncluded(MANIFEST_SITES) || getVal(href).match(SHOPIFY_CHECKOUT_URL_REGEX)) {
	// skip
} else {
	chrome.extension.sendMessage({msgType: "data"}, result => {
		if (result.data && result.data.profile && isIncludedSite(result.data.excludedSites)) {
			setInterval(function() {
					processAIO(result);
				},
				DELAY
			);
		}
	});    
}

function processAIO(result) {
	if (isDocumentInteractiveComplete()) {
		if (result.data.mode === "2" || result.data.mode === "4") {
			addListeners(result);
		} else if (result.data.mode === "5") {
			/* this will be populated by users thru importing data */
			var mode5Eval = result.data.mode5Eval;
			if(mode5Eval) {
				eval(mode5Eval);
			}
		} else if (result.data.mode === "3") {
			/* this will be populated by users thru importing data */
			var mode3Eval = result.data.mode3Eval;
			if(mode3Eval) {
				eval(mode3Eval);
			}
		} else if (result.data.mode === undefined || result.data.mode === "1") {
			process(result);
		}
	}
}

function process(result) {
	processInputAIO(result, "input");
	processInputAIO(result, "textarea");
	processSelect(result);
}

function addListeners(result) {
	if (booleanMapDefault.get(ADD_LISTENER)) {
		for (var input of document.getElementsByTagName("input")) {
			input.addEventListener("focus", function(evt) {
				focusEvent(evt, result);
			});
			mutationObserver.observe(input, {attributes: true});
			booleanMapDefault.set(ADD_LISTENER, false);
		}
		
		for (var input of document.getElementsByTagName("textarea")) {
			input.addEventListener("focus", function(evt) {
				focusEvent(evt, result);
			});
			mutationObserver.observe(input, {attributes: true});
			booleanMapDefault.set(ADD_LISTENER, false);
		}
	}
}

function focusEvent(evt, result) {
	var elem = evt.target;
	process(result);
}

function processRegex(name, input, result) {
	if (name === undefined || name === null || name === "") {
		return false;
	}

	var address = getAddress(name, result);
	var mode = result.data.mode;

	return processRegexNameAndEmail(name, input, result, address, mode) ||
		processName(REGEX_NAME_ADDRESS_2, name, input, address.address2, mode) ||
		processName(REGEX_NAME_ADDRESS_1, name, input, address.address1, mode) ||
		processName(REGEX_NAME_CITY, name, input, address.city, mode) ||
		processName(REGEX_NAME_STATE, name, input, address.province ? address.province.split("/")[0] : "", mode) ||
		processName(REGEX_NAME_ZIP, name, input, address.zip, mode) ||
		processName(REGEX_NAME_PHONE, name, input, address.phone, mode) ||
		processName(REGEX_NAME_CARD_NUMBER, name, input, result.data.profile.card.number, mode) ||
		processName(REGEX_NAME_CARD_EXP_MONTH, name, input, result.data.profile.card.expMonth, mode) ||
		processName(REGEX_NAME_CARD_EXP_YEAR, name, input, result.data.profile.card.expYear, mode) ||
		processName(REGEX_NAME_CARD_EXP_DATE, name, input, result.data.profile.card.expMonth + result.data.profile.card.expYear.substring(2,4), mode) ||
		processName(REGEX_NAME_CARD_CVV, name, input, result.data.profile.card.cvv, mode);
}

function processRegexSelect(name, input, result) {
	if (name === undefined || name === null || name === "") {
		return false;
	}

	var address = getAddress(name, result);

	return processNameSelect(REGEX_NAME_STATE, name, input, address.province, false) ||
		processNameSelect(REGEX_NAME_COUNTRY, name, input, address.country, false) ||
		processNameSelect(REGEX_NAME_CARD_EXP_MONTH, name, input, result.data.profile.card.expMonth, true) ||
		processNameSelect(REGEX_NAME_CARD_EXP_YEAR, name, input, result.data.profile.card.expYear, true) ||
		processNameSelect(REGEX_NAME_CARD_EXP_YEAR, name, input, result.data.profile.card.expYear.substring(2,4), true) ||
		processNameSelect(REGEX_NAME_CARD_TYPE, name, input, getCardType(result.data.profile.card.number), false);
}

function processInputAIO(result, tagName) {
	for (var input of document.getElementsByTagName(tagName)) {
		if (validElement(input)) {
			if (processRegex(getAttr(input, "data-auto-id"), input, result)) {
				saveProductsForWebhookAIO();
				continue;
			}

			var ac = getVal(input.getAttribute("autocomplete"));
			if (ac) {
				var address = getAddress(ac, result);
				var mode = result.data.mode;

				if (processAcNameAndEmail(ac, input, result.data.profile.email, address, mode) ||
					processAc(ac, "street-address", input, address.address1 + " " + address.address2, mode) ||
					processAc(ac, "address-line1", input, address.address1, mode) ||
					processAc(ac, "address-line2", input, address.address2, mode) ||
					processAc(ac, "country", input, address.country, mode) ||
					processAc(ac, "address-level1", input, address.province, mode) ||
					processAc(ac, "address-level2", input, address.city, mode) ||
					processAc(ac, "postal-code", input, address.zip, mode) ||
					processAc(ac, "tel", input, address.phone, mode) ||
					processAc(ac, "cc-number", input, result.data.profile.card.number, mode) ||
					processAc(ac, "cc-exp-month", input, result.data.profile.card.expMonth, mode) ||
					processAc(ac, "cc-exp-year", input, result.data.profile.card.expYear, mode) ||
					processAc(ac, "cc-exp", input, result.data.profile.card.expMonth + " / " + result.data.profile.card.expYear.substring(2,4), mode) ||
					processAc(ac, "cc-csc", input, result.data.profile.card.cvv, mode)) {
					saveProductsForWebhookAIO();
					continue;
				}
			}

			if (processRegex(getVal(input.name), input, result)) {
				saveProductsForWebhookAIO();
				continue;
			}

			if (processRegex(getLabelText(input), input, result)) {
				saveProductsForWebhookAIO();
				continue;
			}

			if (processRegex(getValCustomSite(input.placeholder), input, result)) {
				saveProductsForWebhookAIO();
				continue;
			}

			if (processRegexCheckbox(getVal(input.name), input)) {
				saveProductsForWebhookAIO();
				continue;
			}

			if (processRegex(getVal(input.id), input, result)) {
				saveProductsForWebhookAIO();
				continue;
			}
		}
	}
}

function processSelect(result) {
	for (var input of document.getElementsByTagName("select")) {
		if (validElement(input)) {
			if (processRegexSelect(getSelectName(input), input, result)) {
				saveProductsForWebhookAIO();
				continue;
			}

			var ac = getVal(input.getAttribute("autocomplete"));
			if (ac) {
				var address = result.data.profile.bill;
				if (result.data.profile.ship && ac.includes("shipping")) {
					address = result.data.profile.ship;
				}

				if (processAcSelect(ac, "country", input, address.country) ||
					processAcSelect(ac, "address-level1", input, address.province)) {
					saveProductsForWebhookAIO();
					continue;
				}
			}

			if (processRegexSelect(getLabelText(input), input, result)) {
				saveProductsForWebhookAIO();
				continue;
			}

			if (processRegexSelect(getVal(input.id), input, result)) {
				saveProductsForWebhookAIO();
				continue;
			}
		}
	}
}

function saveProductsForWebhookAIO() {
	if (items.length == 0) {
		var url = null;
		href = getVal(window.location.href);
		if (href.match(ADIDAS_YS_PAYMENT_PAGE_REGEX)) {
			var products = document.getElementsByClassName("line_item___1coA5") && document.getElementsByClassName("line_item___1coA5").length > 0 ? document.getElementsByClassName("line_item___1coA5") : document.getElementsByClassName("line-item");
			if (products) {
				for (var product of products) {
					var image = product.getElementsByTagName("img")[0];
					if (image) {
						var alt;
						try {
							alt = product.innerText.split("\n").slice(0,3).join("\n");
						} catch (e) {
							alt = img.alt;
						}
						items.push({"src": image.src, "alt": alt});
					}
				}
			}
		}

		if (href.match(OFFWHITE_PAYMENT_PAGE_REGEX)) {
			var products = document.getElementsByClassName("cart-items-image");
			if (products) {
				for (var product of products) {
					var image = product.getElementsByTagName("img")[0];
					if (image) {
						items.push({"src": image.src, "alt": image.getAttribute("alt")});
					}
				}
			}
		}

		if (href.match(FOOTSITE_PAYMENT_PAGE_REGEX)) {
			var products = document.getElementsByClassName("FulfillmentProducts-product");
			if (products) {
				for (var product of products) {
					var image = product.getElementsByTagName("img")[0];
					if (image) {
						items.push({"src": image.src, "alt": product.innerText});
					}
				}
			}
		}

		if (href.match(FOOTSITE_EU_REGEX)) {
			var products = document.getElementsByClassName("fl-cart-summary--list--item");
			if (products) {
				for (var product of products) {
					var image = product.getElementsByTagName("img")[0];
					if (image && image.src.startsWith("http")) {
						var alt;
						try {
							alt = product.innerText.split("\n").slice(1,5).join("\n");
						} catch (e) {
							alt = img.alt;
						}
						items.push({"src": image.src, "alt": alt});
					}
				}
			}
		}

		if (href.match(GLOBAL_E_PAGE_REGEX)) {
			url = getGlobalEMerchant();
			items.push({"src": "", "alt": ""});
		}

		if (href.includes("supremenewyork.com/checkout")) {
			items.push({"src": "", "alt": ""});
		}

		if (items.length > 0) {
			chrome.extension.sendMessage({
				msgType: "items",
				items: items,
				url: url
			});
		}
	}	
}

function getValCustomSite(val) {
	if (val === "number" && href.includes("supremenewyork.com")) {
		return "card number";
	}

	return getVal(val);
}

function mutationCallback(mutationsList) {
	mutationsList.forEach(mutation => {
		if (mutation.attributeName === "class") {
			var target = mutation.target;
			if (target && getVal(target.className).includes("invalid")) {
				focusElement(target);
			}
		}
	});
}