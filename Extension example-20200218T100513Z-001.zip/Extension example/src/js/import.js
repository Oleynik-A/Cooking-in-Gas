/*

"Imitation is the sincerest form of flattery" - Charles Caleb Colton

*/

function importJson() {
	try {
		var json = JSON.parse(document.getElementById("json").value);
		
		if (isExtension(json)) {
			saveAndLoad(json);
		} else {
			customAlert("Unexpected format.");
		}
	} catch (e) {
		customAlert("Error importing. Message: " + e.message);
	}
}

function isExtension(json){
	return json.profiles || (json.excludedSites && json.profiles);
}

function saveAndLoad(json) {
	var val = json;
	val["profile"] = json.profiles[0];
	chrome.storage.local.set({data: val}, function(){
		chrome.extension.sendMessage({msgType: "reloadData"});
		customAlert("Import successful!");
	});
	loadData();
}