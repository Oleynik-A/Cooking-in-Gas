/*

"Imitation is the sincerest form of flattery" - Charles Caleb Colton

*/

loadData();

document.onkeyup=function(e){
	var e = e || window.event;
	if (e.altKey && e.which == 78) {
		var profileElement = document.getElementById("profiles");
		var selectedIndex = profileElement.selectedIndex;
		var length = profileElement.length;
		if (selectedIndex + 1 < length) {
			profileElement.selectedIndex = selectedIndex + 1;
			
		} else {
			profileElement.selectedIndex = 0
		}
		dispatchChangeEvent(profileElement);
    }
}

document.getElementById("form2").addEventListener("submit", function (e) {
	e.preventDefault();
});

document.getElementById("import").addEventListener("click", function () {
	var f = document.getElementById("form2");
	if (f.checkValidity()) {
		importJson();
	}
});

document.getElementById("export").addEventListener("click", function () {
	chrome.storage.local.get(["data"], function(result) {
		if (result && result.data.profiles) {
			document.getElementById("json").value = JSON.stringify(
				{	profiles: result.data.profiles,
					excludedSites: result.data.excludedSites,
					mode: result.data.mode,
					webhook: result.data.webhook,
					discord: result.data.discord,
					twitter: result.data.twitter,
					mode3Eval: result.data.mode3Eval,
					mode3Evalv3: result.data.mode3Evalv3,
					mode5Eval: result.data.mode5Eval,
					mode5Evalv3: result.data.mode5Evalv3
				}, null, 2);
		}
	});
});

document.getElementById("billDiffShip").addEventListener("click", function () {
	if (this.checked) {
		showShipFields();
	} else {
		hideShipFields();
	}
});

document.getElementById("testWebhook").addEventListener("click", function () {
	chrome.storage.local.get(["data"], function(result) {
		chrome.storage.local.set({
			data: {
				profiles: result.data.profiles,
				profile: result.data.profile,
				excludedSites: result.data.excludedSites,
				mode: result.data.mode,
				webhook: document.getElementById("webhook").value,
				discord: result.data.discord,
				twitter: result.data.twitter,
				mode3Eval: result.data.mode3Eval,
				mode3Evalv3: result.data.mode3Evalv3,
				mode5Eval: result.data.mode5Eval,
				mode5Evalv3: result.data.mode5Evalv3
			}}, function() {
				chrome.extension.sendMessage({msgType: "testWebhook"});
				chrome.extension.sendMessage({msgType: "reloadData"});
				customAlert("Test Webhook Sent!");
			});
	});
});

document.getElementById("profiles").addEventListener("change", function () {
	chrome.storage.local.get(["data"], function(result) {
		var profiles = [];
		if (result && result.data && result.data.profiles) {
			profiles = result.data.profiles;
		}
		var profileName = document.getElementById("profiles").value;
		if (profiles.length > 0) {
			for (var i = 0; i < profiles.length; i++) {
				if (profiles[i].name == profileName) {
					var val = {
						profiles: result.data.profiles,
						profile: profiles[i],
						excludedSites: document.getElementById("excludedSites").value,
						mode: document.getElementById("mode").value,
						webhook: document.getElementById("webhook").value,
						discord: document.getElementById("discord").value,
						twitter: document.getElementById("twitter").value,
						mode3Eval: result.data.mode3Eval,
						mode3Evalv3: result.data.mode3Evalv3,
						mode5Eval: result.data.mode5Eval,
						mode5Evalv3: result.data.mode5Evalv3
					};
					chrome.storage.local.set({data: val}, function (){
							chrome.extension.sendMessage({msgType: "reloadData"});
							chrome.tabs.query({active: true, currentWindow: true}, function(tabs){
								chrome.tabs.sendMessage(tabs[0].id, {msg: "update"}, null);  
							})
						}
					);
					loadProfile(profiles[i]);
					break;
				}
			}
		}
		document.getElementById("mode").value = result.data.mode;
		document.getElementById("webhook").value = result.data.webhook;
		document.getElementById("discord").value = result.data.discord;
		document.getElementById("twitter").value = result.data.twitter;
		document.getElementById("excludedSites").value = result.data.excludedSites;
	});
});

document.getElementById("setting-tab").style.display = "none";

document.getElementById("profilesButton").addEventListener("click", function () {
	document.getElementById("profile-tab").style.display = "block";
	document.getElementById("setting-tab").style.display = "none";
});

document.getElementById("settingsButton").addEventListener("click", function () {
	document.getElementById("setting-tab").style.display = "block";
	document.getElementById("profile-tab").style.display = "none";
});

function loadData() {
	hideShipFields();
	chrome.storage.local.get(["data"], function(result) {
		if (result && result.data) {
			loadProfiles(result.data.profiles, result.data.profile ? result.data.profile.name : "");
			document.getElementById("excludedSites").value = result.data.excludedSites ? result.data.excludedSites : "";
			document.getElementById("mode").value = result.data.mode ? result.data.mode : "1";
			document.getElementById("webhook").value = result.data.webhook ? result.data.webhook : "";
			document.getElementById("discord").value = result.data.discord ? result.data.discord : "";
			document.getElementById("twitter").value = result.data.twitter ? result.data.twitter : "";
		}
	});
}

function loadProfiles(profs, profileName) {
	if (profs) {
		document.querySelectorAll('.profiles').forEach(function (profiles, index) {
			profiles.length = 0;
			for (let i = 0; i < profs.length; i++) {
				var opt = document.createElement("option");
				opt.text = profs[i].name;
				opt.value = profs[i].name;
				
				if (profs[i].name == profileName) {
					opt.selected = true;
					loadProfile(profs[i]);
				}
				
				profiles.add(opt);

				if (profiles.selectedIndex != -1) {
					loadProfile(profs[profiles.selectedIndex]);
				}
			}
		});
	}
}

function loadProfile(profile) {
	clearAllFields();

	document.getElementById("profileName").value = profile.name;
	document.getElementById("email").value = profile.email;
	document.getElementById("fName").value = profile.bill.fName;
	document.getElementById("lName").value = profile.bill.lName;
	document.getElementById("address1").value = profile.bill.address1;
	document.getElementById("address2").value = profile.bill.address2;
	document.getElementById("city").value = profile.bill.city;
	document.getElementById("country").value = profile.bill.country;
	document.getElementById("province").value = profile.bill.province;
	document.getElementById("zip").value = profile.bill.zip;
	document.getElementById("phone").value = profile.bill.phone;
	document.getElementById("number").value = profile.card.number;
	document.getElementById("expMonth").value = profile.card.expMonth;
	document.getElementById("expYear").value = profile.card.expYear;
	document.getElementById("cvv").value = profile.card.cvv;

	if (profile.ship) {
		showShipFields();
		document.getElementById("shipFName").value = profile.ship.fName;
		document.getElementById("shipLName").value = profile.ship.lName;
		document.getElementById("shipAddress1").value = profile.ship.address1;
		document.getElementById("shipAddress2").value = profile.ship.address2;
		document.getElementById("shipCity").value = profile.ship.city;
		document.getElementById("shipCountry").value = profile.ship.country;
		document.getElementById("shipProvince").value = profile.ship.province;
		document.getElementById("shipZip").value = profile.ship.zip;
		document.getElementById("shipPhone").value = profile.ship.phone;
	} else {
		hideShipFields();
	}
}


document.getElementById("saveProfile").addEventListener("click", function () {
	var f = document.getElementById("form1");
	if (f.checkValidity()) {
		saveProfile();
	}
});

document.getElementById("form1").addEventListener("submit", function (e) {
	e.preventDefault();
});

function saveProfile() {
	chrome.storage.local.get(["data"], function(result) {
		var profiles = [];
		var data = {data: ""};
		if (result && result.data) {
			data = result.data;
		}

		if (data.profiles) {
			profiles = data.profiles;
		}
		
		var profile = {
			name: document.getElementById("profileName").value.trim(),
			email: document.getElementById("email").value.trim(),
			bill: {
				fName: document.getElementById("fName").value.trim(),
				lName: document.getElementById("lName").value.trim(),
				address1: document.getElementById("address1").value.trim(),
				address2: document.getElementById("address2").value.trim(),
				city: document.getElementById("city").value.trim(),
				country: document.getElementById("country").value.trim(),
				province: document.getElementById("province").value.trim(),
				zip: document.getElementById("zip").value.trim(),
				phone: document.getElementById("phone").value.trim()
			},
			card: {
				number: document.getElementById("number").value.trim(),
				expMonth: document.getElementById("expMonth").value.trim(),
				expYear: document.getElementById("expYear").value.trim(),
				cvv: document.getElementById("cvv").value.trim()
			}
		};

		if (document.getElementById("billDiffShip").checked) {
			profile["ship"] = {
				fName: document.getElementById("shipFName").value.trim(),
				lName: document.getElementById("shipLName").value.trim(),
				address1: document.getElementById("shipAddress1").value.trim(),
				address2: document.getElementById("shipAddress2").value.trim(),
				city: document.getElementById("shipCity").value.trim(),
				country: document.getElementById("shipCountry").value.trim(),
				province: document.getElementById("shipProvince").value.trim(),
				zip: document.getElementById("shipZip").value.trim(),
				phone: document.getElementById("shipPhone").value.trim()
			};
		}
		
		if (profiles.length > 0) {
			var newProfile = true;
			for (var i = 0; i < profiles.length; i++) {
				if (profiles[i].name == profile.name) {
					profiles[i] = profile;
					newProfile = false;
					break;
				}
			}
			
			if (newProfile) {
				profiles.push(profile);
			}
		} else {
			profiles.push(profile);
		}
		
		data.profiles = profiles;
		data.profile = profile;
		data.excludedSites = document.getElementById("excludedSites").value.trim();
		data.mode = document.getElementById("mode").value.trim();
		data.webhook = document.getElementById("webhook").value.trim();
		data.discord = document.getElementById("discord").value.trim();
		data.twitter = document.getElementById("twitter").value.trim();
		chrome.storage.local.set({data: data}, function(){
			chrome.extension.sendMessage({msgType: "reloadData"});
		});
		customAlert("Profile with name " + profile.name + " saved!");
		loadProfiles(profiles, profile.name);
		document.getElementById("excludedSites").value = data.excludedSites;
		document.getElementById("mode").value = data.mode;
		document.getElementById("webhook").value = data.webhook;
		document.getElementById("discord").value = data.discord;
		document.getElementById("twitter").value = data.twitter;
	});
}

document.getElementById("saveSettings").addEventListener("click", function () {
	chrome.storage.local.get(["data"], function(result) {
		chrome.storage.local.set({
			data: {
				profiles: result.data.profiles,
				profile: result.data.profile,
				excludedSites: document.getElementById("excludedSites").value,
				mode: document.getElementById("mode").value,
				webhook: document.getElementById("webhook").value,
				discord: document.getElementById("discord").value,
				twitter: document.getElementById("twitter").value,
				mode3Eval: result.data.mode3Eval,
				mode3Evalv3: result.data.mode3Evalv3,
			 	mode5Eval: result.data.mode5Eval,
			 	mode5Evalv3: result.data.mode5Evalv3
			}}, function(){
				chrome.extension.sendMessage({msgType: "reloadData"});
			});
		customAlert("Settings saved!");
	});
});	

document.getElementById("deleteProfile").addEventListener("click", function () {
	var index = document.getElementById("profiles").selectedIndex;
	if (index == -1)  {
		customAlert("Please select a profile to delete from the dropdown.");
	} else {
		customConfirm("Are you sure you want to delete profile '" + document.getElementById("profiles").value + "'?");
	}
});

function deleteProfile() {
	chrome.storage.local.get(["data"], function(result) {
		if (result && result.data && result.data.profiles) {
			var index = document.getElementById("profiles").selectedIndex;
			var filtered = result.data.profiles.filter(function(value, idx, arr){
				return idx != index;
			});		
			result.data.profiles = filtered;
			chrome.storage.local.set({data: result.data}, function(){
				chrome.extension.sendMessage({msgType: "reloadData"});
			});
			customAlert("Profile with name '" + document.getElementById("profiles").value + "' deleted!");
			loadProfiles(filtered);
			document.getElementById("excludedSites").value = result.data.excludedSites;
			document.getElementById("mode").value = result.data.mode;
			document.getElementById("webhook").value = result.data.webhook;
			document.getElementById("discord").value = result.data.discord;
			document.getElementById("twitter").value = result.data.twitter;
		}
	});
}

function clearAllFields() {
	document.getElementById("email").value = "";
	document.getElementById("fName").value = "";
	document.getElementById("lName").value = "";
	document.getElementById("address1").value = "";
	document.getElementById("address2").value = "";
	document.getElementById("city").value = "";
	document.getElementById("country").value = "";
	document.getElementById("province").value = "";
	document.getElementById("zip").value = "";
	document.getElementById("phone").value = "";
	document.getElementById("number").value = "";
	document.getElementById("expMonth").value = "";
	document.getElementById("expYear").value = "";
	document.getElementById("cvv").value = "";
	document.getElementById("excludedSites").value = "";
	document.getElementById("mode").value = "1";
	document.getElementById("webhook").value = "";
	document.getElementById("discord").value = "";
	document.getElementById("twitter").value = "";

	clearShipFields();
}

function clearShipFields() {
	document.getElementById("shipFName").value = "";
	document.getElementById("shipLName").value = "";
	document.getElementById("shipAddress1").value = "";
	document.getElementById("shipAddress2").value = "";
	document.getElementById("shipCity").value = "";
	document.getElementById("shipCountry").value = "";
	document.getElementById("shipProvince").value = "";
	document.getElementById("shipZip").value = "";
	document.getElementById("shipPhone").value = "";
}

function hideShipFields() {
	clearShipFields();
	removeRequiredShipFields();
	document.getElementById("billDiffShip").checked = false;
	document.getElementById("ship-container").style.display = "none";
}

function showShipFields() {
	addRequiredShipFields();
	document.getElementById("billDiffShip").checked = true;
	document.getElementById("ship-container").style.display = "";
}

function removeRequiredShipFields() {
	document.querySelectorAll('.ship-required').forEach(element => {
  		element.required = false;
	});
}

function addRequiredShipFields() {
	document.querySelectorAll('.ship-required').forEach(element => {
  		element.required = true;
	});
}

function customAlert(msg) {
	document.getElementById("myModal").style.display = "block";
	document.getElementById("buttons").style.display = "none";
	document.getElementsByClassName("modal-body")[0].style.height = "70px";
	document.getElementById("msg").innerText = msg;
}

function customConfirm(msg) {
	document.getElementById("myModal").style.display = "block";
	document.getElementById("buttons").style.display = "block";
	document.getElementsByClassName("modal-body")[0].style.height = "100px";
	document.getElementById("msg").innerText = msg;
}

document.getElementsByClassName("close")[0].addEventListener("click", function () {
	document.getElementById("myModal").style.display = "none";
});

window.addEventListener("click", function () {
	var modal = document.getElementById("myModal");
	if (event.target == modal) {
    	modal.style.display = "none";
  	}
});

document.getElementById("deleteYes").addEventListener("click", function () {
	deleteProfile();
});

document.getElementById("deleteNo").addEventListener("click", function () {
	document.getElementById("myModal").style.display = "none";
});