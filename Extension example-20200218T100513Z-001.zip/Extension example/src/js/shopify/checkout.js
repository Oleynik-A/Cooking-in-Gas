/*

"Imitation is the sincerest form of flattery" - Charles Caleb Colton

*/

var setCountry = true;
var setClick = true;
var items = [];

var sid = setInterval(function () {
	chrome.extension.sendMessage({msgType: "data"}, result => {
		if (result.data && result.data.profile && !window.location.href.includes("www.paypal") && isIncludedSite(result.data.excludedSites)) {
			var ship = result.data.profile.ship;

			/** payment page **/
			var radio = document.getElementById("checkout_different_billing_address_true");
			if (radio && setClick) {
				if (ship) {
					setClick = clickElement(radio);
				} else {
					setClick = clickElement(document.getElementById("checkout_different_billing_address_false"));
				}

				setAddress("billing", result.data.profile.bill);
			} else if (document.getElementById("checkout_billing_address_first_name")) {
				setAddress("billing", result.data.profile.bill);
			}

			/** shipping page */

			var email = getElem(document.getElementById("checkout_email"), "billing email");
			var emailOrPhone = getElem(document.getElementById("checkout_email_or_phone"), "shipping email");
			var emailOrPhone2 = document.getElementsByName("checkout[email_or_phone]")[0];
			if (email || emailOrPhone || emailOrPhone2) {
				processInputCheckoutShopify(email, result.data.profile.email);
				processInputCheckoutShopify(emailOrPhone, result.data.profile.email);
				processInputCheckoutShopify(emailOrPhone2, result.data.profile.email);
				setAddress("shipping", ship ? ship : result.data.profile.bill);
			}
		}
	});
}, DELAY);

function setAddress(key, address) {
	if (address) {
		processInputCheckoutShopify(getElem(document.getElementById("checkout_" + key + "_address_first_name"), key + " given-name"), address.fName);
		processInputCheckoutShopify(getElem(document.getElementById("checkout_" + key + "_address_last_name"), key + " family-name"), address.lName);
		processInputCheckoutShopify(getElem(document.getElementById("checkout_" + key + "_address_address1"), key + " address-line1"), address.address1);
		processInputCheckoutShopify(getElem(document.getElementById("checkout_" + key + "_address_address2"), key + " address-line2"), address.address2);
		processInputCheckoutShopify(getElem(document.getElementById("checkout_" + key + "_address_city"), key + " address-level2"), address.city);
		
		var country = getCountryElement(key);
		if (setCountry && setSelectValue(country, address.country, false)) {
			dispatchChangeEvent(country);
			setCountry = false;
			saveProductsForWebhook();
		}

		var province = getProvinceElement(key);
		if (setSelectValue(province, address.province, false)){
			saveProductsForWebhook();
		}

		processInputCheckoutShopify(getElem(document.getElementById("checkout_" + key + "_address_zip"), key + " postal-code"), address.zip);
		processInputCheckoutShopify(getElem(document.getElementById("checkout_" + key + "_address_phone"), key + " tel"), address.phone);
	}
}

function getCountryElement(key) {
	var country = getElemSelect(document.getElementById("checkout_" + key + "_address_country"), key + " country");
	if (country) {
		return country;
	} else {
		return document.getElementsByName("checkout[" + key + "_address][country]")[0];
	}
}

function getProvinceElement(key) {
	var province = getElemSelect(document.getElementById("checkout_" + key + "_address_province"), key + " address-level1");
	if (province) {
		return province;
	} else {
		return document.getElementsByName("checkout[" + key + "_address][province]")[0];
	}
}


function saveProductsForWebhook () {
	if (items.length == 0) {
		var products = document.getElementsByClassName("product__image");
		if (products) {
			for (var product of products) {
				var image = product.getElementsByTagName("img")[0];
				if (image) {
					items.push({"src": image.src, "alt": image.getAttribute("alt")});
				}
			}
			if (items.length > 0) {
				chrome.extension.sendMessage({
					msgType: "items",
					items: items
				});
			}
		}
	}
}


function processInputCheckoutShopify(elem, value) {
	if (elem && isVisible(elem) && !isDisabled(elem) && processInputWithDispatchEvent(elem, value)) {
		saveProductsForWebhook();
	}
}

chrome.extension.onMessage.addListener(function (request, sender, sendResponse) {
	if (request.msg === "update") {
		setValueBackUp(document.getElementById("checkout_billing_address_first_name"), "", "billing given-name");
		setValueBackUp(document.getElementById("checkout_billing_address_last_name"), "", "billing family-name");
		setValueBackUp(document.getElementById("checkout_billing_address_address1"), "", "billing address-line1");
		setValueBackUp(document.getElementById("checkout_billing_address_address2"), "", "billing address-line2");
		setValueBackUp(document.getElementById("checkout_billing_address_city"), "", "billing address-level2");
		setSelectValue(getProvinceElement("billing"), "", false);
		setValueBackUp(document.getElementById("checkout_billing_address_zip"), "", "billing postal-code");
		setValueBackUp(document.getElementById("checkout_billing_address_phone"), "", "billing tel");

		setValueBackUp(document.getElementById("checkout_shipping_address_first_name"), "", "shipping given-name");
		setValueBackUp(document.getElementById("checkout_shipping_address_last_name"), "", "shipping family-name");
		setValueBackUp(document.getElementById("checkout_shipping_address_address1"), "", "shipping address-line1");
		setValueBackUp(document.getElementById("checkout_shipping_address_address2"), "", "shipping address-line2");
		setValueBackUp(document.getElementById("checkout_shipping_address_city"), "", "shipping address-level2");
		setSelectValue(getProvinceElement("shipping"), "", false);
		setValueBackUp(document.getElementById("checkout_shipping_address_zip"), "", "shipping postal-code");
		setValueBackUp(document.getElementById("checkout_shipping_address_phone"), "", "shipping tel");

		setCountry = true;
		setClick = true;

		setValueBackUp(document.getElementById("checkout_email"), "", "billing email");
		setValueBackUp(document.getElementById("checkout_email_or_phone"), "", "shipping email");
		setValue(document.getElementsByName("checkout[email_or_phone]")[0], "");
		clickElement(document.getElementById("checkout_different_billing_address_false"));
	}
});