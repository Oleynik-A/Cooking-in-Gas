/*

"Imitation is the sincerest form of flattery" - Charles Caleb Colton

*/

var sid = setInterval(function () {
	chrome.extension.sendMessage({msgType: "data"}, result => {
		if (result.data && result.data.profile && isIncludedSite(result.data.excludedSites)) {
			processInputPaymentShopify(getElem(document.getElementById("name"), "cc-name"), result.data.profile.bill.fName + " " + result.data.profile.bill.lName);
			processInputPaymentShopify(getElem(document.getElementById("number"), "cc-number"), result.data.profile.card.number);
			processInputPaymentShopify(getElem(document.getElementById("expiry"), "cc-exp"), result.data.profile.card.expMonth + " / " + result.data.profile.card.expYear);
			processInputPaymentShopify(getElem(document.getElementById("verification_value"), "cc-csc"), result.data.profile.card.cvv);
		}	
	});
}, DELAY);

chrome.extension.onMessage.addListener(function (request, sender, sendResponse) {
	if (request.msg === "update") {
		setValueBackUp(document.getElementById("name"), "", "cc-name");
		setValueBackUp(document.getElementById("number"), "", "cc-number");
		setValueBackUp(document.getElementById("expiry"), "", "cc-exp");
		setValueBackUp(document.getElementById("verification_value"), "", "cc-csc");
	}
});

function processInputPaymentShopify(elem, value) {
	if (elem && isVisible(elem) && !isDisabled(elem)) {
		processInputWithDispatchEvent(elem, value);
	}
}