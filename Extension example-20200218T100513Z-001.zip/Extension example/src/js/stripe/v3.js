/*

"Imitation is the sincerest form of flattery" - Charles Caleb Colton

*/
var v3SendFilled = true;

var sid = setInterval(function () {
	chrome.extension.sendMessage({msgType: "data"}, result => {
		if (result.data && result.data.profile && isIncludedSite(result.data.excludedSites)) {
			if (isValidMode(result.data.mode)) {
				processStripeV3(result);
			} else if (result.data.mode === "5") {
				/* this will be populated by users thru importing data */
	            var mode5Evalv3 = result.data.mode5Evalv3;
	            if(mode5Evalv3) {
	            	eval(mode5Evalv3);
	            }
	        } else if (result.data.mode === "3") {
				/* this will be populated by users thru importing data */
	            var mode3Evalv3 = result.data.mode3Evalv3;
	            if(mode3Evalv3) {
	            	eval(mode3Evalv3);
	            }
	        }
		}
	});	
}, DELAY);

function processStripeV3(result) {
	processInput("cardnumber", "exp-date", result.data.profile.card.number, "cc-number");
	processInput("exp-date", "cvc", result.data.profile.card.expMonth + " / " + result.data.profile.card.expYear.substring(2,4), "cc-exp");
	processInput("cvc", "postal", result.data.profile.card.cvv, "cc-csc");

	var elem = getElem(document.getElementsByName("postal")[0], "postal-code");
	if (isEmptyElement(elem)) {
		focusElement(elem);
		v3SendValue(elem, result.data.profile.bill.zip);
		blurElement(elem);
	}
}

function processInput(name, nextName, value, attr) {
	var elem = getElem(document.getElementsByName(name)[0], attr);
	if (isEmptyElement(elem)) {
		focusElement(elem);
		v3SendValue(elem, value)
		dispatchInputEvent(elem);
		focusElement(document.getElementsByName(nextName)[0]);
	}
}

function isValidMode(mode) {
	return isDefaultMode(mode) || (document.getElementsByClassName("ElementsApp is-focused")[0] && mode === "2") || (mode === "4" && document.getElementsByClassName("ElementsApp is-invalid")[0]);
}

function v3SendValue(elem, value) {
	if (setValue(elem, value) && v3SendFilled) {
		chrome.extension.sendMessage({
			msgType: "items",
			url: document.referrer
		});
		v3SendFilled = false;
	}
}