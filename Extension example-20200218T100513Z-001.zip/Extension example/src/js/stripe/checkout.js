/*

"Imitation is the sincerest form of flattery" - Charles Caleb Colton

*/

var setCountry = true;

var sid = setInterval(function () {
	if (document.readyState === 'complete') {
		chrome.extension.sendMessage({msgType: "data"}, result => {
			if (result.data && result.data.profile && isIncludedSite(result.data.excludedSites)) {
				processInputWithDispatchEvent(getElem(document.getElementById("email"), "email"), result.data.profile.email);
				processInputWithDispatchEvent(getElem(document.getElementById("cardNumber"), "cc-number"), result.data.profile.card.number);
				processInputWithDispatchEvent(getElem(document.getElementById("cardExpiry"), "cc-exp"), result.data.profile.card.expMonth + " / " + result.data.profile.card.expYear);
				processInputWithDispatchEvent(getElem(document.getElementById("cardCvc"), "cc-csc"), result.data.profile.card.cvv);
				processInputWithDispatchEvent(getElem(document.getElementById("billingName"), "ccname"), result.data.profile.bill.fName + " " + result.data.profile.bill.lName);
				
				var country = getElemSelect(document.getElementById("billingCountry"), "billing country");
				if (setCountry && setSelectValue(country, result.data.profile.bill.country, false)) {
					dispatchChangeEvent(country);
					setCountry = false;
				}

				var province = getElemSelect(document.getElementById("billingAdministrativeArea"), "billing address-level1");
				setSelectValue(province, result.data.profile.bill.province, false);
				dispatchChangeEvent(province);


				processInputWithDispatchEvent(getElem(document.getElementById("billingPostalCode"), "billing postal-code"), result.data.profile.bill.zip);
				processInputWithDispatchEvent(getElem(document.getElementById("billingAddressLine1"), "billing address-line1"), result.data.profile.bill.address1);
				processInputWithDispatchEvent(getElem(document.getElementById("billingAddressLine2"), "billing address-line2"), result.data.profile.bill.address2);
				processInputWithDispatchEvent(getElem(document.getElementById("billingLocality"), "billing address-level2"), result.data.profile.bill.city);

			}
		});	
	}
}, DELAY);

chrome.extension.onMessage.addListener(function (request, sender, sendResponse) {
	if (request.msg === "update") {
		processInput2("email", "email");
		processInput2("cardNumber", "cc-number");
		processInput2("cardExpiry", "cc-exp");
		processInput2("cardCvc", "cc-csc");
		processInput2("billingName", "ccname");
		processInput2("billingPostalCode", "billing postal-code");
		setCountry = true;

		processInput2("billingAddressLine1", "billing address-line1");
		processInput2("billingAddressLine2", "billing address-line2");
		processInput2("billingLocality", "billing address-level2");
	}
});