/*

"Imitation is the sincerest form of flattery" - Charles Caleb Colton

*/

var sid = setInterval(function () {
	chrome.extension.sendMessage({msgType: "data"}, result => {
		if (result.data && result.data.profile && isIncludedSite(result.data.excludedSites)) {
			var inputFields = document.getElementsByClassName("Fieldset-input");
			if (inputFields) {
				for (var i = 0; i < inputFields.length; i++) {
					var inputField = inputFields[i];

					if (inputField) {
						if (inputField.className.includes("Select-control") && setSelectValue(inputField, result.data.profile.bill.country, false)) {
							dispatchInputEvent(inputField);
						} else {
							var value = "";
							switch(inputField.placeholder) {
								case "Email": value = result.data.profile.email; break;
								case "Name": value = result.data.profile.bill.fName + " " + result.data.profile.bill.lName; break;
								case "Street":value = result.data.profile.bill.address1 + " " + result.data.profile.bill.address2; break;
								case "City": value = result.data.profile.bill.city; break;
								case "ZIP Code":
								case "Postcode": value = result.data.profile.bill.zip; break;
								case "Card number": value = result.data.profile.card.number; break;
								case "MM / YY": value = result.data.profile.card.expMonth + " / " + result.data.profile.card.expYear; break;
								case "CVC": value = result.data.profile.card.cvv; break;
							}

							if (validElement(inputField)) {
								processInputWithDispatchEvent(inputField, value);
							}
						}
					}
				}
			}
		}
	});
}, DELAY);

chrome.extension.onMessage.addListener(function (request, sender, sendResponse) {
	if (request.msg === "update") {
		var inputFields = document.getElementsByClassName("Fieldset-input");
		if (inputFields) {
			for (var i = 0; i < inputFields.length; i++) {
				setValue(inputFields[i], "");
				dispatchInputEvent(inputFields[i]);
			}
		}
	}
});