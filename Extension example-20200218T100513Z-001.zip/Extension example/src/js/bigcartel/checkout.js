/*

"Imitation is the sincerest form of flattery" - Charles Caleb Colton

*/

var items = [];
var SET_COUNTRY = "setCountry";
var AUTO_FILLED = "autoFilled";

var booleanMapBigCartel = new Map();
booleanMapBigCartel.set(SET_COUNTRY, true);
booleanMapBigCartel.set(AUTO_FILLED, false);

var sid = setInterval(function () {
	if (isDocumentReady()) {
		chrome.extension.sendMessage({msgType: "data"}, result => {
			if (result.data && result.data.profile && isIncludedSite(result.data.excludedSites)) {
				processInputCheckoutBigCartel(getValidElem(document.getElementById("buyer_first_name"), document.getElementsByName("buyer_first_name")[0]), result.data.profile.bill.fName);
				processInputCheckoutBigCartel(getValidElem(document.getElementById("buyer_last_name"), document.getElementsByName("buyer_last_name")[0]), result.data.profile.bill.lName);
				processInputCheckoutBigCartel(getValidElem(document.getElementById("buyer_email"), document.getElementsByName("buyer_email")[0]), result.data.profile.email);
				processInputCheckoutBigCartel(getValidElem(document.getElementById("buyer_phone_number"), document.getElementsByName("buyer_phone_number")[0]), result.data.profile.bill.phone);
				
				setAddress(result.data.profile.ship ? result.data.profile.ship : result.data.profile.bill);

				if (booleanMapBigCartel.get(AUTO_FILLED) && items.length == 0) {
					saveProductsForWebhook();
				}
			}
		});
	}
}, DELAY);

function setAddress(address) {
	processInputCheckoutBigCartel(getValidElem(document.getElementById("shipping_address_1"), document.getElementsByName("shipping_address_1")[0]), address.address1);
	processInputCheckoutBigCartel(document.getElementsByName("shipping_address_2")[0], address.address2);
	processInputCheckoutBigCartel(document.getElementsByName("shipping_city")[0], address.city);
	processInputCheckoutBigCartel(document.getElementsByName("shipping_zip")[0], address.zip);
	
	var country = document.getElementsByName("shipping_country_id")[0];
	if (booleanMapBigCartel.get(SET_COUNTRY) && setSelectValue(country, address.country, false)) {
		dispatchChangeEvent(country);
		booleanMapBigCartel.set(SET_COUNTRY, false);
	}
	
	var state = document.getElementsByName("shipping_state")[0];
	if (state && state.tagName.toLowerCase() === "input") {
		processInputCheckoutBigCartel(state, address.province);
	} else if (state && state.tagName.toLowerCase() === "select") {
		setSelectValue(state, address.province, false);
	}
}

function processInputCheckoutBigCartel(elem, value) {
	if (validElement(elem) && processInputWithDispatchEvent(elem, value)) {
		booleanMapBigCartel.set(AUTO_FILLED, true);
	}
}

function saveProductsForWebhook () {
	var products = document.getElementsByClassName("product");
	if (products) {
		for (var product of products) {
			items.push({"src": AUTO_FILL_ICON, "alt": getVal(product.innerText)});
		}

		var sf = document.getElementsByName("storefront")[0];
		var a = document.getElementsByTagName("a")[0];

		if (items.length > 0) {
			chrome.extension.sendMessage({
				msgType: "items",
				items: items,
				url: sf ? sf.content : (a ? a.href : "https://checkout.bigcartel.com/")
			});
		}
	}
}