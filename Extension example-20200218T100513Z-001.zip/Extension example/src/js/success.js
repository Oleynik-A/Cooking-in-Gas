/*

"Imitation is the sincerest form of flattery" - Charles Caleb Colton

*/

const MAP = [
	{
		"type": "kw",
		"site": "cybersole.io",
		"eval": "document.getElementById(\"payment-form\") ? document.getElementById(\"payment-form\").innerText : \"\"",
		"regex": new RegExp("Welcome\\s+to\\s+the\\s+team\nYou\\s+will\\s+receive\\s+an\\s+email\\s+with\\s+your\\s+license\\s+shortly.\nDashboard", "i")
	},
	{
		"type": "kw",
		"site": "cybersole.io",
		"eval": "document.getElementById(\"form\") ? document.getElementById(\"form\").innerText : \"\"",
		"regex": new RegExp("Welcome\\s+to\\s+the\\s+team\nYou\\s+will\\s+receive\\s+an\\s+email\\s+with\\s+your\\s+license\\s+shortly.", "i")
	},
	{
		"type": "supreme",
		"site": "supremenewyork.com/checkout",
	},
	{
		"type": "globale",
		"site": "webservices.global-e.com/checkout/v2"
	}
];

var url = getVal(window.location.href);

successTimeout();

function successTimeout() {
	if (successProcess()) {
		setTimeout(function() {
				successTimeout();
			},
			3000
		);
	}
}

function successProcess() {
	for (var kw of MAP) {
		if(kw.type === "kw" && url.includes(kw.site)) {
			var text = eval(kw.eval);
			if (text && text.match(kw.regex)) {
				chrome.extension.sendMessage({
					msgType: "keywords",
					"image": successGetImage(),
					"text": text
				});
				return false;
			}
		} else if(kw.type === "supreme" && url.includes(kw.site) && document.getElementsByClassName("tab-confirmation selected") && document.getElementsByClassName("tab-confirmation selected").length > 0) {
			var items = [];

			var products = document.getElementsByClassName("purchase-row");
			if (products) {
				for (var product of products) {
					var image = product.getElementsByTagName("img")[0];
					if (image) {
						items.push({"src": image.src, "alt": image.alt});
					}
				}
			}

			if (items.length > 0) {
				chrome.extension.sendMessage({
					msgType: "itemsSuccess",
					items: items
				});
				return false;
			}
		} else if(kw.type === "globale" && url.includes(kw.site) && document.getElementById("orderRefNum") && document.getElementById("conf-header")) {
			var items = [];

			var products = document.getElementsByClassName("row item");
			if (products) {
				for (var product of products) {
					var image = product.getElementsByTagName("img")[0];
					if (image && image.src.startsWith("http")) {
						items.push({"src": image.src, "alt": product.innerText.split("\n").slice(0,2).join("\n")});
					}
				}
			}

			if (items.length > 0) {
				chrome.extension.sendMessage({
					msgType: "itemsSuccess",
					items: items,
					url: getGlobalEMerchant() 
				});
				return false;
			}
		}
	}

	return true;
}

function successGetImage() {
	for (var img of document.getElementsByTagName("img")) {
		if (img && img.src.includes(".svg")) {
			continue;
		}
		return img.src;
	}

	return AUTO_FILL_ICON;
}