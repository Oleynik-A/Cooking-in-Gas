/*

"Imitation is the sincerest form of flattery" - Charles Caleb Colton

*/

var DELAY = 25;
var CARD_TYPE_MAP = new Map(); /* Thanks to https://gist.github.com/genecyber/5a13ba6a553e3995bbcc9cc2e61075fa */
var EVENT_PARAMS = { bubbles: true };
const AUTO_FILL_ICON = "https://i.imgur.com/dI7i9Wl.png";

CARD_TYPE_MAP.set(new RegExp("^4"), "Visa");
CARD_TYPE_MAP.set(new RegExp("^5[1-5]"), "Mastercard");
CARD_TYPE_MAP.set(new RegExp("^3[47]"), "American Express");
CARD_TYPE_MAP.set(new RegExp("^(6011|622(12[6-9]|1[3-9][0-9]|[2-8][0-9]{2}|9[0-1][0-9]|92[0-5]|64[4-9])|65)"), "Discover");
CARD_TYPE_MAP.set(new RegExp("^36"), "Diners");
CARD_TYPE_MAP.set(new RegExp("^30[0-5]"), "Diners - Carte Blanche");
CARD_TYPE_MAP.set(new RegExp("^35(2[89]|[3-8][0-9])"), "JCB");
CARD_TYPE_MAP.set(new RegExp("^(4026|417500|4508|4844|491(3|7))"), "Visa Electron");

const MANIFEST_SITES = "checkout.stripe.com/m/v3,js.stripe.com/v3/elements-inner-card,checkout.stripe.com/pay,.shopifycs.com,checkout.bigcartel.com";

const GLOBAL_E_GET_MERCHANT_REGEX = new RegExp("redToMerchantURL\\s+:\\s+\"(.+?)\"", "i");

function dispatchEvent(elem, params, type) {
	if (typeof elem.dispatchEvent === "function") {
		elem.dispatchEvent(new Event(type, params));
	}
}

function dispatchInputEvent(elem) {
	if (elem) {
		dispatchEvent(elem, EVENT_PARAMS, "input");
	}
}

function dispatchChangeEvent(elem) {
	if (elem) {
		dispatchEvent(elem, EVENT_PARAMS, "change");
	}
}

function dispatchKeyupEvent(elem) {
	if (elem) {
		dispatchEvent(elem, EVENT_PARAMS, "keyup");
	}
}

function dispatchKeydownEvent(elem) {
	if (elem) {
		dispatchEvent(elem, EVENT_PARAMS, "keydown");
	}
}

function setSelectValue(elem, val, isNumeric) {
	if (elem && elem.options && val) {
		for (var val of val.split("/")) {
			for (var opt of elem.options) {
				value = getStringOrNumeric(val, isNumeric);
				if (getStringOrNumeric(opt.value, isNumeric) === value || getStringOrNumeric(opt.innerText, isNumeric) === value
					|| (opt.getAttribute("data-code") && getStringOrNumeric(opt.getAttribute("data-code"), isNumeric) === value)) {
					if (opt.selected || elem.value === opt.value || elem.getAttribute("af")) {
						elem.setAttribute("af", true);
						break;
					} else {
						opt.selected = true;
						elem.value = opt.value;
						elem.setAttribute("af", true);
						dispatchChangeEvent(elem);
						return true;
					}
				}
			}
		}
	}

	return false;
}

function setValue(elem, val) {
	if (elem) {
		elem.value = val;
		return true;
	}
	return false;
}

function setValueBackUp(elem, val, attr) {
	setValue(getElem(elem, attr), val);
}

function getElementBasedOnAttrbiute(tag, attr) {
	for (var elem of document.getElementsByTagName(tag)) {
		if (attr === getVal(elem.getAttribute("autocomplete")) && "visually-hidden" != getVal(elem.getAttribute("class"))) {
			return elem;
		}
	}
	return null;
}

function getElemSelect(elem, attr) {
	if (elem) {
		return elem;
	} else {
		return getElementBasedOnAttrbiute("select", attr);
	}
}

function getElem(elem, attr) {
	if (elem) {
		return elem;
	} else {
		return getElementBasedOnAttrbiute("input", attr);
	}
}

function getValidElem(elem1, elem2) {
	if (elem1) {
		return elem1;
	}
	
	if (elem2) {
		return elem2;
	}
	
	return null;
}

function getValue(elem) {
	if (elem) {
		return elem.value.trim();
	}
	
	return "";
}

function getVal(value) {
	if (value) {
		return value.trim().toLowerCase();
	}
	return "";
}

function getValNumeric(value) {
	if (value) {
		return parseInt(value);
	}
	return NaN;
}

function getStringOrNumeric(value, isNumeric) {
	if (isNumeric) {
		return getValNumeric(value);
	}

	return getVal(value);
}

function focusElement(elem) {
	if (elem) {
		elem.focus();
	}
}

function blurElement(elem) {
	if (elem) {
		elem.blur();
	}
}

function clickElement(elem) {
	if (elem) {
		elem.click();
		return false;
	}

	return true;
}

function isEmptyElement(elem) {
	return validElement(elem) && getValue(elem).length == 0;
}

function isEmpty(name) {
	return isExist(name) && getValue(document.getElementsByName(name)[0]).length == 0;
}

function isExist(name) {
	return document.getElementsByName(name)[0];
}

function processInput(elem, value) {
	if (isEmptyElement(elem)) {
		setValue(elem, value ? value.trim() : value);
	}
}

function processInput2(name, attr) {
	var elem = getElem(document.getElementsByName(name)[0], attr);
	setValue(elem, "");
	dispatchInputEvent(elem);
}

function processInputWithDispatchEvent(elem, value) {
	if (elem && getValue(elem).length == 0) {
		if (value) {
			focusElement(elem);
			dispatchKeydownEvent(elem);
			setValue(elem, value ? value.trim() : value);
			dispatchChangeEvent(elem);
			dispatchInputEvent(elem);
			dispatchKeyupEvent(elem);
		}
		return true;
	}
	return false;
}

function isDocumentReady() {
	return document.readyState === "complete";
}

function isDocumentInteractiveComplete() {
	return document.readyState === "interactive" || document.readyState === "complete";
}

function validElement(elem) {
	return elem && isVisible(elem) && !isElementInViewport(elem) && !isDisabled(elem);
}

function isVisible(elem) {
	return elem.offsetWidth > 0 && elem.offsetHeight > 0;
}

function isDisabled(elem) {
	return (elem.getAttribute("disabled") && elem.getAttribute("disabled").toLowerCase() === "disabled") || elem.disabled;
}

function isElementInViewport(elem) {
	/** Credit to http://jsfiddle.net/cferdinandi/b13ctvd7/ */
	var bounding = elem.getBoundingClientRect();
	var out = {};
	out.top = Math.trunc(bounding.top) < 0;
	out.left = Math.trunc(bounding.left) < 0;
	out.bottom = Math.trunc(bounding.bottom) > (Math.trunc(window.innerHeight) || Math.trunc(document.documentElement.clientHeight));
	out.right = Math.trunc(bounding.right) > (Math.trunc(window.innerWidth) || Math.trunc(document.documentElement.clientWidth));
	out.any = out.top || out.left || out.bottom || out.right;

	return out.any;
}

/** accepts excluded sites list paramter **/
function isIncludedSite(excludedSites) {
	if (excludedSites) {
		var sites = excludedSites.toLowerCase().split(",");
		if (sites && sites.length > 0) {
			var referrer = isIframe() && document.referrer ? document.referrer.toLowerCase() : document.location.href;
			for (var site of sites) {
				site = getVal(site);
				if (site === "") {
					continue;
				}
				if (referrer.includes(site)) {
					return false;
				}
			}
		}
	}

	return true;
}

function isIframe () {
    try {
        return window.self !== window.top;
    } catch (e) {
        return true;
    }
}

function isMatch(elem, val) {
    if (elem) {
        var r = new RegExp(val + "(?:\\W|\\s|$)", "i");
        if ((elem.innerText && elem.innerText.match(r)) || (elem.value && elem.value.match(r))) {
            return true;
        }
    }
    return false;
}

function isSiteIncluded(includedSites) {
	if (includedSites) {
		var sites = includedSites.toLowerCase().split(",");
		if (sites && sites.length > 0) {
			/*var referrer = getVal(isIframe() && document.referrer ? document.referrer.toLowerCase() : document.location.href);*/
			var referrer = document.location.href;
			for (var site of sites) {
				if (referrer.match(new RegExp(site, "i"))) {
					return true;
				}
			}
		}
	}

	return false;
}

function processName(regex, name, elem, value, mode) {
	if (name.match(regex)) {
		if (isDefaultMode(mode)) {
			return processInputWithDispatchEvent(elem, value);
		} else {
			return setValue(elem, value);
		}
	}
	return false;
}

function processNameSelect(regex, name, elem, value, isNumeric) {
	if (name.match(regex)) {
		return setSelectValue(elem, value, isNumeric);
	}
	return false;
}

function processAc(ac, attribute, elem, value, mode) {
	if (ac === attribute || ac.includes(attribute)) {
		if (isDefaultMode(mode)) {
			return processInputWithDispatchEvent(elem, value);
		} else {
			return setValue(elem, value);
		}
	}
	return false;
}

function processAcSelect(ac, attribute, elem, value) {
	if (ac === attribute || ac.includes(attribute)) {
		return setSelectValue(elem, value, false);
	}
	return false;
}

function getSelectName(input) {
	var attr = getAttr(input, "data-auto-id");
	if (attr) {
		return attr;
	}

	var parent = input.parentElement;
    if (parent) {
 		attr = getAttr(parent, "data-auto-id");
 		if (attr) {
 			return attr;
 		}
	}

	var name = getVal(input.name);

	if (name) {
		return name;
	}

	return null;
}

function processAcNameAndEmail(ac, input, email, address, mode) {
	return processAc(ac, "email", input, email, mode) ||
		processAc(ac, "given-name", input, address.fName, mode) ||
		processAc(ac, "family-name", input, address.lName, mode) ||
		processAc(ac, "name", input, address.fName + " " + address.lName, mode) ||
		processAc(ac, "cc-name", input, address.fName + " " + address.lName, mode);
}

function processRegexNameAndEmail(name, input, result, address, mode) {
	return processName(REGEX_NAME_FULL_NAME, name, input, address.fName + " " + address.lName, mode) ||
		processName(REGEX_NAME_FIRST_NAME, name, input, address.fName, mode) ||
		processName(REGEX_NAME_LAST_NAME, name, input, address.lName, mode) ||
		processName(REGEX_NAME_EMAIL, name, input, result.data.profile.email, mode) ||
		processName(REGEX_NAME_CARD_NAME, name, input, address.fName + " " + address.lName, mode) ||
		processName(REGEX_NAME_DISCORD_TAG, name, input, result.data.discord, mode) ||
		processName(REGEX_NAME_TWITTER_HANDLE, name, input, result.data.twitter, mode);
}

function processRegexCheckbox(name, input) {
	return processCheckbox(REGEX_NAME_CHECKBOX, name, input);
}

function processCheckbox(regex, name, input) {
	if (input && getVal(input.type) === "checkbox") {
		if (input.checked) {
			return true;
		} else if (name.match(regex) || getAttr(input, "data-auto-id").match(regex)) {
			if (input.nextElementSibling && getVal(input.nextElementSibling.tagName) === "ins") {
				input.nextElementSibling.click();
			} else {
				input.click();
				input.checked = true;
			}
			return true;
		}
	}

	return false;
}

function getCardType(number) {
	for (const [key, value] of CARD_TYPE_MAP) {
		if (number.match(key)) {
			return value;
		}
	}

	return "";
}

function getLabelText(input) {
	var id = input.id;
	if (id) {
		var label = document.querySelector("label[for='" + id + "']");
		if (label) {
			return getVal(label.innerText);
		}
	}

	var parent = input.parentElement;
	if (parent) {
		var previous = parent.previousElementSibling;
		if (previous && previous.tagName.toLowerCase() === "label") {
			return getVal(previous.innerText);
		}
	}

	return "";
}

function getAddress(name, result) {
	var address = result.data.profile.bill;
	if (result.data.profile.ship && name.includes("ship")) {
		address = result.data.profile.ship;
	}

	return address;
}

function getAttr(input, attr) {
	var attribute = "";
	if (input) {
		attribute = getVal(input.getAttribute(attr));
	}

	return attribute;
}

function isDefaultMode(mode) {
	return mode === undefined || mode === "1"
}

function getGlobalEMerchant() {
	var html = document.getElementsByTagName("html")[0];
	if (html && html.innerHTML) {
		var m = html.innerHTML.match(GLOBAL_E_GET_MERCHANT_REGEX);
		if (m) {
			return m[1];
		}
	}
	return "https://webservices.global-e.com";
}