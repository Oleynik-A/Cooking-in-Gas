
const REGEX_NAME_FULL_NAME = new RegExp(
    "^name|full.?name|your.?name|customer.?name|bill.?name|ship.?name"
    + "|name.*first.*last|firstandlastname"
    /*"|nombre.*y.*apellidos"  // es
    "|^nom(?!bre)"           // fr-FR
    "|お名前|氏名"           // ja-JP
    "|^nome"                 // pt-BR, pt-PT
    "|نام.*نام.*خانوادگی"    // fa
    "|姓名"                  // zh-CN
    "|성명";                 // ko-KR*/
, "i");
const REGEX_NAME_FIRST_NAME = new RegExp(
	"first.*name|initials|fname|first$|given.*name|^firstname$|^fname$"
    /*"|vorname"                 // de-DE
    "|nombre"                  // es
    "|forename|prénom|prenom"  // fr-FR
    "|名"                      // ja-JP
    "|nome"                    // pt-BR, pt-PT
    "|Имя"                     // ru
    "|نام"                     // fa
    "|이름"                    // ko-KR
    "|പേര്"                     // ml
    "|नाम";                    // hi*/
, "i");
const REGEX_NAME_LAST_NAME = new RegExp(
	"last.*name|lname|surname|last$|secondname|family.*name"
    /*"|nachname"                            // de-DE
    "|apellidos?"                          // es
    "|famille|^nom(?!bre)"                 // fr-FR
    "|cognome"                             // it-IT
    "|姓"                                  // ja-JP
    "|morada|apelidos|surename|sobrenome"  // pt-BR, pt-PT
    "|Фамилия"                             // ru
    "|نام.*خانوادگی"                       // fa
    "|उपनाम"                               // hi
    "|മറുപേര്"                               // ml
    "|\\b성(?:[^명]|\\b)";                 // ko-KR*/
, "i");
const REGEX_NAME_ADDRESS_1 = new RegExp(
    "^address$|address[_-]?line(one)?|address1|addr1|street"
    /*"|(?:shipping|billing)address$"
    "|strasse|straße|hausnummer|housenumber"  // de-DE
    "|house.?name"                            // en-GB
    "|direccion|dirección"                    // es
    "|adresse"                                // fr-FR
    "|indirizzo"                              // it-IT
    "|^住所$|住所1"                           // ja-JP
    "|morada|endereço"                        // pt-BR, pt-PT
    "|Адрес"                                  // ru
    "|地址"                                   // zh-CN
    "|^주소.?$|주소.?1";                      // ko-KR*/
, "i");
const REGEX_NAME_ADDRESS_2 = new RegExp(
	"address[_-]?line(2|two)|address.?2|addr2|street.?(?:#|no|num|nr)|suite|unit"
    /*"|adresszusatz|ergänzende.?angaben"        // de-DE
    "|direccion2|colonia|adicional"            // es
    "|addresssuppl|complementnom|appartement"  // fr-FR
    "|indirizzo2"                              // it-IT
    "|住所2"                                   // ja-JP
    "|complemento|addrcomplement"              // pt-BR, pt-PT
    "|Улица"                                   // ru
    "|地址2"                                   // zh-CN
    "|주소.?2";                                // ko-KR*/
, "i");
const REGEX_NAME_CITY = new RegExp(
	"city|town"
    /*"|\\bort\\b|stadt"                       // de-DE
    "|suburb"                                // en-AU
    "|ciudad|provincia|localidad|poblacion"  // es
    "|ville|commune"                         // fr-FR
    "|localita"                              // it-IT
    "|市区町村"                              // ja-JP
    "|cidade"                                // pt-BR, pt-PT
    "|Город"                                 // ru
    "|市"                                    // zh-CN
    "|分區"                                  // zh-TW
    "|شهر"                                   // fa
    "|शहर"                                   // hi for city
    "|ग्राम|गाँव"                              // hi for village
    "|നഗരം|ഗ്രാമം"                            // ml for town|village
    "|^시[^도·・]|시[·・]?군[·・]?구";       // ko-KR*/
, "i");
const REGEX_NAME_STATE = new RegExp(
    "(?<!(united|hist|history).?)state|county|region|province"
    /*"|county|principality"  // en-UK
    "|都道府県"             // ja-JP
    "|estado|provincia"     // pt-BR, pt-PT
    "|область"              // ru
    "|省"                   // zh-CN
    "|地區"                 // zh-TW
    "|സംസ്ഥാനം"              // ml
    "|استان"                // fa
    "|राज्य"                 // hi
    "|^시[·・]?도";         // ko-KR*/
, "i");
const REGEX_NAME_COUNTRY = new RegExp(
    "country|countries"
    /*"|país|pais"           // es
    "|land(?!.*(mark.*))"  // de-DE landmark is another field type in India.
    "|(?<!(入|出))国"      // ja-JP
    "|国家"                // zh-CN
    "|국가|나라"           // ko-KR
    "|کشور";               // fa*/
, "i");
const REGEX_NAME_ZIP = new RegExp(
    "zip|postal|post.*code|pcode"
    /*"|pin.?code"                    // en-IN
    "|postleitzahl"                 // de-DE
    "|\\bcp\\b"                     // es
    "|\\bcdp\\b"                    // fr-FR
    "|\\bcap\\b"                    // it-IT
    "|郵便番号"                     // ja-JP
    "|codigo|codpos|\\bcep\\b"      // pt-BR, pt-PT
    "|Почтовый.?Индекс"             // ru
    "|पिन.?कोड"                     // hi
    "|പിന്‍കോഡ്"  // ml
    "|邮政编码|邮编"                // zh-CN
    "|郵遞區號"                     // zh-TW
    "|우편.?번호";                  // ko-KR*/
, "i");
const REGEX_NAME_EMAIL = new RegExp(
	"e.?mail"
    /*"|courriel"                 // fr
    "|correo.*electr(o|ó)nico"  // es-ES
    "|メールアドレス"           // ja-JP
    "|Электронной.?Почты"       // ru
    "|邮件|邮箱"                // zh-CN
    "|電郵地址"                 // zh-TW
    "|ഇ-മെയില്‍|ഇലക്ട്രോണിക്.?"
    "മെയിൽ"                                        // ml
    "|ایمیل|پست.*الکترونیک"                        // fa
    "|ईमेल|इलॅक्ट्रॉनिक.?मेल"                           // hi
    "|(?:이메일|전자.?우편|[Ee]-?mail)(.?주소)?";  // ko-KR*/
, "i");
const REGEX_NAME_PHONE = new RegExp(
    "phone|mobile|contact.?number|tel"
    /*"|telefonnummer"                                // de-DE
    "|telefono|teléfono"                            // es
    "|telfixe"                                      // fr-FR
    "|電話"                                         // ja-JP
    "|telefone|telemovel"                           // pt-BR, pt-PT
    "|телефон"                                      // ru
    "|मोबाइल"                                       // hi for mobile
    "|电话"                                         // zh-CN
    "|മൊബൈല്‍"                        // ml for mobile
    "|(?:전화|핸드폰|휴대폰|휴대전화)(?:.?번호)?";  // ko-KR*/
, "i");
const REGEX_NAME_CARD_NAME = new RegExp(
    "card.?(?:holder|owner)|name.*(\\b)?on(\\b)?.*card"
    /*"|(?:card|cc).?name|cc.?full.?name"
    "|karteninhaber"                   // de-DE
    "|nombre.*tarjeta"                 // es
    "|nom.*carte"                      // fr-FR
    "|nome.*cart"                      // it-IT
    "|名前"                            // ja-JP
    "|Имя.*карты"                      // ru
    "|信用卡开户名|开户名|持卡人姓名"  // zh-CN
    "|持卡人姓名";                     // zh-TW*/
, "i");
const REGEX_NAME_CARD_NUMBER = new RegExp(
    "(add)?(?:card|cc|acct).?(?:number|#|no|field)|carn|credit.*?card.*?cnb"
    /*"|(?<!telefon|haus)nummer"  // de-DE
    "|カード番号"               // ja-JP
    "|Номер.*карты"             // ru
    "|信用卡号|信用卡号码"      // zh-CN
    "|信用卡卡號"               // zh-TW
    "|카드"                     // ko-KR
    // es/pt/fr
    "|(numero|número|numéro)(?!.*(document|fono|phone|réservation))";*/
, "i");
const REGEX_NAME_CARD_CVV = new RegExp(
    "verification|card.?identification|security.?code|card.?code"
    + "|security.?value"
    + "|security.?number|card.?pin|c-v-v"
    + "|(cvn|cvv|cvc|csc|cvd|cid|ccv)(field)?"
    + "|\\bcid\\b"
, "i");
const REGEX_NAME_CARD_EXP_MONTH = new RegExp(
    "exp.*mo|ccmonth|card.?month|addmonth"
    /*"|gueltig|gültig|monat"  // de-DE
    "|fecha"                 // es
    "|date.*exp"             // fr-FR
    "|scadenza"              // it-IT
    "|有効期限"              // ja-JP
    "|validade"              // pt-BR, pt-PT
    "|Срок действия карты"   // ru
    "|月";                   // zh-CN*/
, "i");
const REGEX_NAME_CARD_EXP_YEAR = new RegExp(
    "(?:exp|payment|card).*(?:year|yr)"
    /*"|ablaufdatum|gueltig|gültig|jahr"  // de-DE
    "|fecha"                            // es
    "|scadenza"                         // it-IT
    "|有効期限"                         // ja-JP
    "|validade"                         // pt-BR, pt-PT
    "|Срок действия карты"              // ru
    "|年|有效期";                       // zh-CN*/
, "i");
const REGEX_NAME_CARD_TYPE = new RegExp(
    "(credit)?card.*type"
    /*"|ablaufdatum|gueltig|gültig|jahr"  // de-DE
    "|fecha"                            // es
    "|scadenza"                         // it-IT
    "|有効期限"                         // ja-JP
    "|validade"                         // pt-BR, pt-PT
    "|Срок действия карты"              // ru
    "|年|有效期";                       // zh-CN*/
, "i");
// Used to match a expiration date field with a two digit year.
// The following conditions must be met:
//  - Exactly two adjacent y's.
//  - (optional) Exactly two adjacent m's before the y's.
//    - (optional) Separated by white-space and/or a dash or slash.
//  - (optional) Prepended with some text similar to "Expiration Date".
// Tested in components/autofill/core/common/autofill_regexes_unittest.cc
//const char kExpirationDate2DigitYearRe[] =
 //   "(?:exp.*date[^y\\n\\r]*|mm\\s*[-/]?\\s*)yy(?:[^y]|$)";
// Used to match a expiration date field with a four digit year.
// Same requirements as |kExpirationDate2DigitYearRe| except:
//  - Exactly four adjacent y's.
// Tested in components/autofill/core/common/autofill_regexes_unittest.cc
//const char kExpirationDate4DigitYearRe[] =
    //"(?:exp.*date[^y\\n\\r]*|mm\\s*[-/]?\\s*)yyyy(?:[^y]|$)";
// Used to match expiration date fields that do not specify a year length.
const REGEX_NAME_CARD_EXP_DATE = new RegExp(
    "expir|exp.*date|^expfield$"
    /*"|gueltig|gültig"        // de-DE
    "|fecha"                 // es
    "|date.*exp"             // fr-FR
    "|scadenza"              // it-IT
    "|有効期限"              // ja-JP
    "|validade"              // pt-BR, pt-PT
    "|Срок действия карты";  // ru*/
, "i");
const REGEX_NAME_DISCORD_TAG = new RegExp(
    "discord.*?(tag)?"
, "i");
const REGEX_NAME_TWITTER_HANDLE = new RegExp(
    "twitter.*?handle"
, "i");
const REGEX_NAME_CHECKBOX = new RegExp(
    "(order)?.*?terms"
    + "|consent.*?(checkbox)?|Terms And Conditions"
, "i");

/*
// Copyright 2013 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

// This file contains UTF8 strings that we want as char arrays.  To avoid
// different compilers, we use a script to convert the UTF8 strings into
// numeric literals (\x##).

#include "components/autofill/core/common/autofill_REGEX_NAME_constants.h"

namespace autofill {

/////////////////////////////////////////////////////////////////////////////
// address_field.cc
/////////////////////////////////////////////////////////////////////////////
const char kAttentionIgnoredRe[] = "attention|attn";
const char kRegionIgnoredRe[] =
    "province|region|other"
    "|provincia"       // es
    "|bairro|suburb";  // pt-BR, pt-PT
const char kAddressNameIgnoredRe[] = "address.*nickname|address.*label";
const char kCompanyRe[] =
    "company|business|organization|organisation"
    "|(?<!con)firma|firmenname"  // de-DE
    "|empresa"                   // es
    "|societe|société"           // fr-FR
    "|ragione.?sociale"          // it-IT
    "|会社"                      // ja-JP
    "|название.?компании"        // ru
    "|单位|公司"                 // zh-CN
    "|شرکت"                      // fa
    "|회사|직장";                // ko-KR
const char kAddressLine1Re[] =
    "^address$|address[_-]?line(one)?|address1|addr1|street"
    "|(?:shipping|billing)address$"
    "|strasse|straße|hausnummer|housenumber"  // de-DE
    "|house.?name"                            // en-GB
    "|direccion|dirección"                    // es
    "|adresse"                                // fr-FR
    "|indirizzo"                              // it-IT
    "|^住所$|住所1"                           // ja-JP
    "|morada|endereço"                        // pt-BR, pt-PT
    "|Адрес"                                  // ru
    "|地址"                                   // zh-CN
    "|^주소.?$|주소.?1";                      // ko-KR
const char kAddressLine1LabelRe[] =
    "(^\\W*address)"
    "|(address\\W*$)"
    "|(?:shipping|billing|mailing|pick.?up|drop.?off|delivery|sender|postal|"
    "recipient|home|work|office|school|business|mail)[\\s\\-]+address"
    "|address\\s+(of|for|to|from)"
    "|adresse"    // fr-FR
    "|indirizzo"  // it-IT
    "|住所"       // ja-JP
    "|地址"       // zh-CN
    "|주소";      // ko-KR
const char kAddressLine2Re[] =
    "address[_-]?line(2|two)|address2|addr2|street|suite|unit"
    "|adresszusatz|ergänzende.?angaben"        // de-DE
    "|direccion2|colonia|adicional"            // es
    "|addresssuppl|complementnom|appartement"  // fr-FR
    "|indirizzo2"                              // it-IT
    "|住所2"                                   // ja-JP
    "|complemento|addrcomplement"              // pt-BR, pt-PT
    "|Улица"                                   // ru
    "|地址2"                                   // zh-CN
    "|주소.?2";                                // ko-KR
const char kAddressLine2LabelRe[] =
    "address|line"
    "|adresse"    // fr-FR
    "|indirizzo"  // it-IT
    "|地址"       // zh-CN
    "|주소";      // ko-KR
const char kAddressLinesExtraRe[] =
    "address.*line[3-9]|address[3-9]|addr[3-9]|street|line[3-9]"
    "|municipio"           // es
    "|batiment|residence"  // fr-FR
    "|indirizzo[3-9]";     // it-IT
const char kAddressLookupRe[] = "lookup";
const char kCountryRe[] =
    "country|countries"
    "|país|pais"           // es
    "|land(?!.*(mark.*))"  // de-DE landmark is another field type in India.
    "|(?<!(入|出))国"      // ja-JP
    "|国家"                // zh-CN
    "|국가|나라"           // ko-KR
    "|کشور";               // fa
const char kCountryLocationRe[] = "location";
const char kZipCodeRe[] =
    "zip|postal|post.*code|pcode"
    "|pin.?code"                    // en-IN
    "|postleitzahl"                 // de-DE
    "|\\bcp\\b"                     // es
    "|\\bcdp\\b"                    // fr-FR
    "|\\bcap\\b"                    // it-IT
    "|郵便番号"                     // ja-JP
    "|codigo|codpos|\\bcep\\b"      // pt-BR, pt-PT
    "|Почтовый.?Индекс"             // ru
    "|पिन.?कोड"                     // hi
    "|പിന്‍കോഡ്"  // ml
    "|邮政编码|邮编"                // zh-CN
    "|郵遞區號"                     // zh-TW
    "|우편.?번호";                  // ko-KR
const char kZip4Re[] =
    "zip|^-$|post2"
    "|codpos2";  // pt-BR, pt-PT
const char kCityRe[] =
    "city|town"
    "|\\bort\\b|stadt"                       // de-DE
    "|suburb"                                // en-AU
    "|ciudad|provincia|localidad|poblacion"  // es
    "|ville|commune"                         // fr-FR
    "|localita"                              // it-IT
    "|市区町村"                              // ja-JP
    "|cidade"                                // pt-BR, pt-PT
    "|Город"                                 // ru
    "|市"                                    // zh-CN
    "|分區"                                  // zh-TW
    "|شهر"                                   // fa
    "|शहर"                                   // hi for city
    "|ग्राम|गाँव"                              // hi for village
    "|നഗരം|ഗ്രാമം"                            // ml for town|village
    "|^시[^도·・]|시[·・]?군[·・]?구";       // ko-KR
const char kStateRe[] =
    "(?<!(united|hist|history).?)state|county|region|province"
    "|county|principality"  // en-UK
    "|都道府県"             // ja-JP
    "|estado|provincia"     // pt-BR, pt-PT
    "|область"              // ru
    "|省"                   // zh-CN
    "|地區"                 // zh-TW
    "|സംസ്ഥാനം"              // ml
    "|استان"                // fa
    "|राज्य"                 // hi
    "|^시[·・]?도";         // ko-KR

/////////////////////////////////////////////////////////////////////////////
// search_field.cc
/////////////////////////////////////////////////////////////////////////////
const char kSearchTermRe[] =
    "^q$"
    "|search"
    "|query"
    "|qry"
    "|suche.*"              // de-DE
    "|搜索"                 // zh-CN zh-TW
    "|探す|検索"            // ja-JP to search
    "|recherch.*"           // fr-FR
    "|busca"                // pt-BR, pt-PT
    "|جستجو"                // fa
    "|искать|найти|поиск";  // ru

/////////////////////////////////////////////////////////////////////////////
// field_price.cc
/////////////////////////////////////////////////////////////////////////////
const char kPriceRe[] =
    "\\bprice\\b|\\brate\\b|\\bcost\\b"
    "|قیمة‎|سعر‎"                          // ar
    "|قیمت"                                           // fa
    "|\\bprix\\b|\\bcoût\\b|\\bcout\\b|\\btarif\\b";  // fr-CA

/////////////////////////////////////////////////////////////////////////////
// credit_card_field.cc
/////////////////////////////////////////////////////////////////////////////
const char kNameOnCardRe[] =
    "card.?(?:holder|owner)|name.*(\\b)?on(\\b)?.*card"
    "|(?:card|cc).?name|cc.?full.?name"
    "|karteninhaber"                   // de-DE
    "|nombre.*tarjeta"                 // es
    "|nom.*carte"                      // fr-FR
    "|nome.*cart"                      // it-IT
    "|名前"                            // ja-JP
    "|Имя.*карты"                      // ru
    "|信用卡开户名|开户名|持卡人姓名"  // zh-CN
    "|持卡人姓名";                     // zh-TW
const char kNameOnCardContextualRe[] = "name";
const char kCardNumberRe[] =
    "(add)?(?:card|cc|acct).?(?:number|#|no|num|field)"
    "|(?<!telefon|haus)nummer"  // de-DE
    "|カード番号"               // ja-JP
    "|Номер.*карты"             // ru
    "|信用卡号|信用卡号码"      // zh-CN
    "|信用卡卡號"               // zh-TW
    "|카드"                     // ko-KR
    // es/pt/fr
    "|(numero|número|numéro)(?!.*(document|fono|phone|réservation))";

const char kCardCvcRe[] =
    "verification|card.?identification|security.?code|card.?code"
    "|security.?value"
    "|security.?number|card.?pin|c-v-v"
    "|(cvn|cvv|cvc|csc|cvd|cid|ccv)(field)?"
    "|\\bcid\\b";

// "Expiration date" is the most common label here, but some pages have
// "Expires", "exp. date" or "exp. month" and "exp. year".  We also look
// for the field names ccmonth and ccyear, which appear on at least 4 of
// our test pages.

// On at least one page (The China Shop2.html) we find only the labels
// "month" and "year".  So for now we match these words directly; we'll
// see if this turns out to be too general.

// Toolbar Bug 51451: indeed, simply matching "month" is too general for
//   https://rps.fidelity.com/ftgw/rps/RtlCust/CreatePIN/Init.
// Instead, we match only words beginning with "month".
const char kExpirationMonthRe[] =
    "expir|exp.*mo|exp.*date|ccmonth|cardmonth|addmonth"
    "|gueltig|gültig|monat"  // de-DE
    "|fecha"                 // es
    "|date.*exp"             // fr-FR
    "|scadenza"              // it-IT
    "|有効期限"              // ja-JP
    "|validade"              // pt-BR, pt-PT
    "|Срок действия карты"   // ru
    "|月";                   // zh-CN
const char kExpirationYearRe[] =
    "exp|^/|(add)?year"
    "|ablaufdatum|gueltig|gültig|jahr"  // de-DE
    "|fecha"                            // es
    "|scadenza"                         // it-IT
    "|有効期限"                         // ja-JP
    "|validade"                         // pt-BR, pt-PT
    "|Срок действия карты"              // ru
    "|年|有效期";                       // zh-CN

// Used to match a expiration date field with a two digit year.
// The following conditions must be met:
//  - Exactly two adjacent y's.
//  - (optional) Exactly two adjacent m's before the y's.
//    - (optional) Separated by white-space and/or a dash or slash.
//  - (optional) Prepended with some text similar to "Expiration Date".
// Tested in components/autofill/core/common/autofill_regexes_unittest.cc
const char kExpirationDate2DigitYearRe[] =
    "(?:exp.*date[^y\\n\\r]*|mm\\s*[-/]?\\s*)yy(?:[^y]|$)";
// Used to match a expiration date field with a four digit year.
// Same requirements as |kExpirationDate2DigitYearRe| except:
//  - Exactly four adjacent y's.
// Tested in components/autofill/core/common/autofill_regexes_unittest.cc
const char kExpirationDate4DigitYearRe[] =
    "(?:exp.*date[^y\\n\\r]*|mm\\s*[-/]?\\s*)yyyy(?:[^y]|$)";
// Used to match expiration date fields that do not specify a year length.
const char kExpirationDateRe[] =
    "expir|exp.*date|^expfield$"
    "|gueltig|gültig"        // de-DE
    "|fecha"                 // es
    "|date.*exp"             // fr-FR
    "|scadenza"              // it-IT
    "|有効期限"              // ja-JP
    "|validade"              // pt-BR, pt-PT
    "|Срок действия карты";  // ru
const char kGiftCardRe[] = "gift.?card";
const char kDebitGiftCardRe[] =
    "(?:visa|mastercard|discover|amex|american express).*gift.?card";
const char kDebitCardRe[] = "debit.*card";

/////////////////////////////////////////////////////////////////////////////
// email_field.cc
/////////////////////////////////////////////////////////////////////////////
const char kEmailRe[] =
    "e.?mail"
    "|courriel"                 // fr
    "|correo.*electr(o|ó)nico"  // es-ES
    "|メールアドレス"           // ja-JP
    "|Электронной.?Почты"       // ru
    "|邮件|邮箱"                // zh-CN
    "|電郵地址"                 // zh-TW
    "|ഇ-മെയില്‍|ഇലക്ട്രോണിക്.?"
    "മെയിൽ"                                        // ml
    "|ایمیل|پست.*الکترونیک"                        // fa
    "|ईमेल|इलॅक्ट्रॉनिक.?मेल"                           // hi
    "|(?:이메일|전자.?우편|[Ee]-?mail)(.?주소)?";  // ko-KR

/////////////////////////////////////////////////////////////////////////////
// name_field.cc
/////////////////////////////////////////////////////////////////////////////
const char kNameIgnoredRe[] =
    "user.?name|user.?id|nickname|maiden name|title|prefix|suffix"
    "|vollständiger.?name"              // de-DE
    "|用户名"                           // zh-CN
    "|(?:사용자.?)?아이디|사용자.?ID";  // ko-KR
const char kNameRe[] =
    "^name|full.?name|your.?name|customer.?name|bill.?name|ship.?name"
    "|name.*first.*last|firstandlastname"
    "|nombre.*y.*apellidos"  // es
    "|^nom(?!bre)"           // fr-FR
    "|お名前|氏名"           // ja-JP
    "|^nome"                 // pt-BR, pt-PT
    "|نام.*نام.*خانوادگی"    // fa
    "|姓名"                  // zh-CN
    "|성명";                 // ko-KR
const char kNameSpecificRe[] =
    "^name"
    "|^nom"    // fr-FR
    "|^nome";  // pt-BR, pt-PT
const char kFirstNameRe[] =
    "first.*name|initials|fname|first$|given.*name"
    "|vorname"                 // de-DE
    "|nombre"                  // es
    "|forename|prénom|prenom"  // fr-FR
    "|名"                      // ja-JP
    "|nome"                    // pt-BR, pt-PT
    "|Имя"                     // ru
    "|نام"                     // fa
    "|이름"                    // ko-KR
    "|പേര്"                     // ml
    "|नाम";                    // hi
const char kMiddleInitialRe[] = "middle.*initial|m\\.i\\.|mi$|\\bmi\\b";
const char kMiddleNameRe[] =
    "middle.*name|mname|middle$"
    "|apellido.?materno|lastlastname";  // es

// TODO(crbug.com/928851): Revisit "morada" from pt-PT as it means address and
// not "last name", and "surename" in pt-PT as it's not Portuguese (or any
// language?).
const char kLastNameRe[] =
    "last.*name|lname|surname|last$|secondname|family.*name"
    "|nachname"                            // de-DE
    "|apellidos?"                          // es
    "|famille|^nom(?!bre)"                 // fr-FR
    "|cognome"                             // it-IT
    "|姓"                                  // ja-JP
    "|morada|apelidos|surename|sobrenome"  // pt-BR, pt-PT
    "|Фамилия"                             // ru
    "|نام.*خانوادگی"                       // fa
    "|उपनाम"                               // hi
    "|മറുപേര്"                               // ml
    "|\\b성(?:[^명]|\\b)";                 // ko-KR

/////////////////////////////////////////////////////////////////////////////
// phone_field.cc
/////////////////////////////////////////////////////////////////////////////
const char kPhoneRe[] =
    "phone|mobile|contact.?number"
    "|telefonnummer"                                // de-DE
    "|telefono|teléfono"                            // es
    "|telfixe"                                      // fr-FR
    "|電話"                                         // ja-JP
    "|telefone|telemovel"                           // pt-BR, pt-PT
    "|телефон"                                      // ru
    "|मोबाइल"                                       // hi for mobile
    "|电话"                                         // zh-CN
    "|മൊബൈല്‍"                        // ml for mobile
    "|(?:전화|핸드폰|휴대폰|휴대전화)(?:.?번호)?";  // ko-KR
const char kCountryCodeRe[] =
    "country.*code|ccode|_cc|phone.*code|user.*phone.*code";
const char kAreaCodeNotextRe[] = "^\\($";
const char kAreaCodeRe[] =
    "area.*code|acode|area"
    "|지역.?번호";  // ko-KR
const char kPhonePrefixSeparatorRe[] = "^-$|^\\)$";
const char kPhoneSuffixSeparatorRe[] = "^-$";
const char kPhonePrefixRe[] =
    "prefix|exchange"
    "|preselection"  // fr-FR
    "|ddd";          // pt-BR, pt-PT
const char kPhoneSuffixRe[] = "suffix";
const char kPhoneExtensionRe[] =
    "\\bext|ext\\b|extension"
    "|ramal";  // pt-BR, pt-PT

/////////////////////////////////////////////////////////////////////////////
// travel_field.cc
/////////////////////////////////////////////////////////////////////////////

const char kPassportRe[] =
    "document.*number|passport"     // en-US
    "|passeport"                    // fr-FR
    "|numero.*documento|pasaporte"  // es-ES
    "|書類";                        // ja-JP
const char kTravelOriginRe[] =
    "point.*of.*entry|arrival"                // en-US
    "|punto.*internaci(o|ó)n|fecha.*llegada"  // es-ES
    "|入国";                                  // ja-JP
const char kTravelDestinationRe[] =
    "departure"               // en-US
    "|fecha.*salida|destino"  // es-ES
    "|出国";                  // ja-JP
const char kFlightRe[] =
    "airline|flight"                    // en-US
    "|aerol(i|í)nea|n(u|ú)mero.*vuelo"  // es-ES
    "|便名|航空会社";                   // ja-JP

/////////////////////////////////////////////////////////////////////////////
// validation.cc
/////////////////////////////////////////////////////////////////////////////
const char kUPIVirtualPaymentAddressRe[] =
    "^[\\w.+-_]+@("        // eg user@
    "\\w+\\.ifsc\\.npci|"  // IFSC code
    "aadhaar\\.npci|"      // Aadhaar number
    "mobile\\.npci|"       // Mobile number
    "rupay\\.npci|"        // RuPay card number
    "airtel|"  // List of banks https://www.npci.org.in/upi-live-members
    "airtelpaymentsbank|"
    "albk|"
    "allahabadbank|"
    "allbank|"
    "andb|"
    "apb|"
    "apl|"
    "axis|"
    "axisbank|"
    "axisgo|"
    "bandhan|"
    "barodampay|"
    "birla|"
    "boi|"
    "cbin|"
    "cboi|"
    "centralbank|"
    "cmsidfc|"
    "cnrb|"
    "csbcash|"
    "csbpay|"
    "cub|"
    "dbs|"
    "dcb|"
    "dcbbank|"
    "denabank|"
    "dlb|"
    "eazypay|"
    "equitas|"
    "ezeepay|"
    "fbl|"
    "federal|"
    "finobank|"
    "hdfcbank|"
    "hsbc|"
    "icici|"
    "idbi|"
    "idbibank|"
    "idfc|"
    "idfcbank|"
    "idfcnetc|"
    "ikwik|"
    "imobile|"
    "indbank|"
    "indianbank|"
    "indianbk|"
    "indus|"
    "iob|"
    "jkb|"
    "jsb|"
    "jsbp|"
    "karb|"
    "karurvysyabank|"
    "kaypay|"
    "kbl|"
    "kbl052|"
    "kmb|"
    "kmbl|"
    "kotak|"
    "kvb|"
    "kvbank|"
    "lime|"
    "lvb|"
    "lvbank|"
    "mahb|"
    "obc|"
    "okaxis|"
    "okbizaxis|"
    "okhdfcbank|"
    "okicici|"
    "oksbi|"
    "paytm|"
    "payzapp|"
    "pingpay|"
    "pnb|"
    "pockets|"
    "psb|"
    "purz|"
    "rajgovhdfcbank|"
    "rbl|"
    "sbi|"
    "sc|"
    "scb|"
    "scbl|"
    "scmobile|"
    "sib|"
    "srcb|"
    "synd|"
    "syndbank|"
    "syndicate|"
    "tjsb|"
    "tjsp|"
    "ubi|"
    "uboi|"
    "uco|"
    "unionbank|"
    "unionbankofindia|"
    "united|"
    "upi|"
    "utbi|"
    "vijayabank|"
    "vijb|"
    "vjb|"
    "ybl|"
    "yesbank|"
    "yesbankltd"
    ")$";

const char kInternationalBankAccountNumberRe[] =
    "^[a-zA-Z]{2}[0-9]{2}[a-zA-Z0-9]{4}[0-9]{7}([a-zA-Z0-9]?){0,16}$";

// Matches all 3 and 4 digit numbers.
const char kCreditCardCVCPattern[] = "^\\d{3,4}$";

// Matches numbers in the range [2010-2099].
const char kCreditCard4DigitExpYearPattern[] = "^[2][0][1-9][0-9]$";

/////////////////////////////////////////////////////////////////////////////
// form_structure.cc
/////////////////////////////////////////////////////////////////////////////
const char kUrlSearchActionRe[] = "/search(/|((\\w*\\.\\w+)?$))";

}  // namespace autofill
*/

const REGEX_NAME_PASSWORD = new RegExp("^password$|^Password$|pwd", "i");
const REGEX_NAME_BIRTHDAY = new RegExp("^birthday$|^Birthday$|^birth-day$", "i");
const REGEX_NAME_BUTTON = new RegExp("step__footer__continue-btn|Button-animationWrapper-child--primary|btn-proceed-final");
var regexArray = {
	firstName: REGEX_NAME_FIRST_NAME,
	lastName: REGEX_NAME_LAST_NAME,
	email: REGEX_NAME_EMAIL,
	phoneNumber: REGEX_NAME_PHONE,
	address: REGEX_NAME_ADDRESS_1,
	address2: REGEX_NAME_ADDRESS_2,
	city: REGEX_NAME_CITY,
	zipcode: REGEX_NAME_ZIP,
	state: REGEX_NAME_STATE,
	country: REGEX_NAME_COUNTRY,
	cardholderName: REGEX_NAME_CARD_NAME,
	cardType: REGEX_NAME_CARD_TYPE,
	cardNumber: REGEX_NAME_CARD_NUMBER,
	expiryMonth: REGEX_NAME_CARD_EXP_MONTH,
	expiryYear: REGEX_NAME_CARD_EXP_YEAR,
	cvv: REGEX_NAME_CARD_CVV,
	password: REGEX_NAME_PASSWORD,
    birthday: REGEX_NAME_BIRTHDAY,
    button: REGEX_NAME_BUTTON,
    checkbox: REGEX_NAME_CHECKBOX
};



var DELAY = 25;
var CARD_TYPE_MAP = new Map(); /* Thanks to https://gist.github.com/genecyber/5a13ba6a553e3995bbcc9cc2e61075fa */
var EVENT_PARAMS = { bubbles: true };


CARD_TYPE_MAP.set(new RegExp("^4"), "Visa");
CARD_TYPE_MAP.set(new RegExp("^5[1-5]"), "Mastercard");
CARD_TYPE_MAP.set(new RegExp("^3[47]"), "American Express");
CARD_TYPE_MAP.set(new RegExp("^(6011|622(12[6-9]|1[3-9][0-9]|[2-8][0-9]{2}|9[0-1][0-9]|92[0-5]|64[4-9])|65)"), "Discover");
CARD_TYPE_MAP.set(new RegExp("^36"), "Diners");
CARD_TYPE_MAP.set(new RegExp("^30[0-5]"), "Diners - Carte Blanche");
CARD_TYPE_MAP.set(new RegExp("^35(2[89]|[3-8][0-9])"), "JCB");
CARD_TYPE_MAP.set(new RegExp("^(4026|417500|4508|4844|491(3|7))"), "Visa Electron");

const MANIFEST_SITES = "checkout.stripe.com/m/v3,js.stripe.com/v3/elements-inner-card,checkout.stripe.com/pay,.shopifycs.com,checkout.bigcartel.com";

const GLOBAL_E_GET_MERCHANT_REGEX = new RegExp("redToMerchantURL\\s+:\\s+\"(.+?)\"", "i");

function dispatchEvent(elem, params, type) {
	if (typeof elem.dispatchEvent === "function") {
		elem.dispatchEvent(new Event(type, params));
	}
}

function dispatchInputEvent(elem) {
	if (elem) {
		dispatchEvent(elem, EVENT_PARAMS, "input");
	}
}

function dispatchChangeEvent(elem) {
	if (elem) {
		dispatchEvent(elem, EVENT_PARAMS, "change");
	}
}

function dispatchKeyupEvent(elem) {
	if (elem) {
		dispatchEvent(elem, EVENT_PARAMS, "keyup");
	}
}

function dispatchKeydownEvent(elem) {
	if (elem) {
		dispatchEvent(elem, EVENT_PARAMS, "keydown");
	}
}

function setSelectValue(elem, val, isNumeric) {
	if (elem && elem.options && val) {
		for (var val of val.split("/")) {
			for (var opt of elem.options) {
				value = getStringOrNumeric(val, isNumeric);
				if (getStringOrNumeric(opt.value, isNumeric) === value || getStringOrNumeric(opt.innerText, isNumeric) === value
					|| (opt.getAttribute("data-code") && getStringOrNumeric(opt.getAttribute("data-code"), isNumeric) === value)) {
					if (opt.selected || elem.value === opt.value || elem.getAttribute("af")) {
						elem.setAttribute("af", true);
						break;
					} else {
						opt.selected = true;
						elem.value = opt.value;
						elem.setAttribute("af", true);
						dispatchChangeEvent(elem);
						return true;
					}
				}
			}
		}
	}

	return false;
}

function setValue(elem, val) {
	if (elem) {
		elem.value = val;
		return true;
	}
	return false;
}

function setValueBackUp(elem, val, attr) {
	setValue(getElem(elem, attr), val);
}

function getElementBasedOnAttrbiute(tag, attr) {
	for (var elem of document.getElementsByTagName(tag)) {
		if (attr === getVal(elem.getAttribute("autocomplete")) && "visually-hidden" != getVal(elem.getAttribute("class"))) {
			return elem;
		}
	}
	return null;
}

function getElemSelect(elem, attr) {
	if (elem) {
		return elem;
	} else {
		return getElementBasedOnAttrbiute("select", attr);
	}
}

function getElem(elem, attr) {
	if (elem) {
		return elem;
	} else {
		return getElementBasedOnAttrbiute("input", attr);
	}
}

function getValidElem(elem1, elem2) {
	if (elem1) {
		return elem1;
	}
	
	if (elem2) {
		return elem2;
	}
	
	return null;
}

function getValue(elem) {
	if (elem) {
		return elem.value.trim();
	}
	
	return "";
}

function getVal(value) {
	if (value) {
		return value.trim().toLowerCase();
	}
	return "";
}

function getValNumeric(value) {
	if (value) {
		return parseInt(value);
	}
	return NaN;
}

function getStringOrNumeric(value, isNumeric) {
	if (isNumeric) {
		return getValNumeric(value);
	}

	return getVal(value);
}

function focusElement(elem) {
	if (elem) {
		elem.focus();
	}
}

function blurElement(elem) {
	if (elem) {
		elem.blur();
	}
}

function clickElement(elem) {
	if (elem) {
		elem.click();
		return false;
	}

	return true;
}

function isEmptyElement(elem) {
	return validElement(elem) && getValue(elem).length == 0;
}

function isEmpty(name) {
	return isExist(name) && getValue(document.getElementsByName(name)[0]).length == 0;
}

function isExist(name) {
	return document.getElementsByName(name)[0];
}

function processInput(elem, value) {
	if (isEmptyElement(elem)) {
		setValue(elem, value ? value.trim() : value);
	}
}

function processInput2(name, attr) {
	var elem = getElem(document.getElementsByName(name)[0], attr);
	setValue(elem, "");
	dispatchInputEvent(elem);
}

function processInputWithDispatchEvent(elem, value) {
	if (elem && getValue(elem).length == 0) {
		if (value) {
			focusElement(elem);
			dispatchKeydownEvent(elem);
			setValue(elem, value ? value.trim() : value);
			dispatchChangeEvent(elem);
			dispatchInputEvent(elem);
			dispatchKeyupEvent(elem);
		}
		return true;
	}
	return false;
}

function isDocumentReady() {
	return document.readyState === "complete";
}

function isDocumentInteractiveComplete() {
	return document.readyState === "interactive" || document.readyState === "complete";
}

function validElement(elem) {
	return elem && isVisible(elem) && !isElementInViewport(elem) && !isDisabled(elem);
}

function isVisible(elem) {
	return elem.offsetWidth > 0 && elem.offsetHeight > 0;
}

function isDisabled(elem) {
	return (elem.getAttribute("disabled") && elem.getAttribute("disabled").toLowerCase() === "disabled") || elem.disabled;
}

function isElementInViewport(elem) {
	/** Credit to http://jsfiddle.net/cferdinandi/b13ctvd7/ */
	var bounding = elem.getBoundingClientRect();
	var out = {};
	out.top = Math.trunc(bounding.top) < 0;
	out.left = Math.trunc(bounding.left) < 0;
	out.bottom = Math.trunc(bounding.bottom) > (Math.trunc(window.innerHeight) || Math.trunc(document.documentElement.clientHeight));
	out.right = Math.trunc(bounding.right) > (Math.trunc(window.innerWidth) || Math.trunc(document.documentElement.clientWidth));
	out.any = out.top || out.left || out.bottom || out.right;

	return out.any;
}

/** accepts excluded sites list paramter **/
function isIncludedSite(excludedSites) {
	if (excludedSites) {
		var sites = excludedSites.toLowerCase().split(",");
		if (sites && sites.length > 0) {
			var referrer = isIframe() && document.referrer ? document.referrer.toLowerCase() : document.location.href;
			for (var site of sites) {
				site = getVal(site);
				if (site === "") {
					continue;
				}
				if (referrer.includes(site)) {
					return false;
				}
			}
		}
	}

	return true;
}

function isIframe () {
    try {
        return window.self !== window.top;
    } catch (e) {
        return true;
    }
}

function isMatch(elem, val) {
    if (elem) {
        var r = new RegExp(val + "(?:\\W|\\s|$)", "i");
        if ((elem.innerText && elem.innerText.match(r)) || (elem.value && elem.value.match(r))) {
            return true;
        }
    }
    return false;
}

function isSiteIncluded(includedSites) {
	if (includedSites) {
		var sites = includedSites.toLowerCase().split(",");
		if (sites && sites.length > 0) {
			/*var referrer = getVal(isIframe() && document.referrer ? document.referrer.toLowerCase() : document.location.href);*/
			var referrer = document.location.href;
			for (var site of sites) {
				if (referrer.match(new RegExp(site, "i"))) {
					return true;
				}
			}
		}
	}

	return false;
}

function processName(regex, name, elem, value, mode) {
	if (name.match(regex)) {
		if (isDefaultMode(mode)) {
			return processInputWithDispatchEvent(elem, value);
		} else {
			return setValue(elem, value);
		}
	}
	return false;
}

function processNameSelect(regex, name, elem, value, isNumeric) {
	if (name.match(regex)) {
		return setSelectValue(elem, value, isNumeric);
	}
	return false;
}

function processAc(ac, attribute, elem, value, mode) {
	if (ac === attribute || ac.includes(attribute)) {
		if (isDefaultMode(mode)) {
			return processInputWithDispatchEvent(elem, value);
		} else {
			return setValue(elem, value);
		}
	}
	return false;
}

function processAcSelect(ac, attribute, elem, value) {
	if (ac === attribute || ac.includes(attribute)) {
		return setSelectValue(elem, value, false);
	}
	return false;
}

function getSelectName(input) {
	var attr = getAttr(input, "data-auto-id");
	if (attr) {
		return attr;
	}

	var parent = input.parentElement;
    if (parent) {
 		attr = getAttr(parent, "data-auto-id");
 		if (attr) {
 			return attr;
 		}
	}

	var name = getVal(input.name);

	if (name) {
		return name;
	}

	return null;
}

function processAcNameAndEmail(ac, input, email, address, mode) {
	return processAc(ac, "email", input, email, mode) ||
		processAc(ac, "given-name", input, address.fName, mode) ||
		processAc(ac, "family-name", input, address.lName, mode) ||
		processAc(ac, "name", input, address.fName + " " + address.lName, mode) ||
		processAc(ac, "cc-name", input, address.fName + " " + address.lName, mode);
}

function processRegexNameAndEmail(name, input, result, address, mode) {
	return processName(REGEX_NAME_FULL_NAME, name, input, address.fName + " " + address.lName, mode) ||
		processName(REGEX_NAME_FIRST_NAME, name, input, address.fName, mode) ||
		processName(REGEX_NAME_LAST_NAME, name, input, address.lName, mode) ||
		processName(REGEX_NAME_EMAIL, name, input, result.data.profile.email, mode) ||
		processName(REGEX_NAME_CARD_NAME, name, input, address.fName + " " + address.lName, mode) ||
		processName(REGEX_NAME_DISCORD_TAG, name, input, result.data.discord, mode) ||
		processName(REGEX_NAME_TWITTER_HANDLE, name, input, result.data.twitter, mode);
}

function processRegexCheckbox(name, input) {
	return processCheckbox(REGEX_NAME_CHECKBOX, name, input);
}

function processCheckbox(regex, name, input) {
	if (input && getVal(input.type) === "checkbox") {
		if (input.checked) {
			return true;
		} else if (name.match(regex) || getAttr(input, "data-auto-id").match(regex)) {
			if (input.nextElementSibling && getVal(input.nextElementSibling.tagName) === "ins") {
				input.nextElementSibling.click();
			} else {
				input.click();
				input.checked = true;
			}
			return true;
		}
	}

	return false;
}

function getCardType(number) {
	for (const [key, value] of CARD_TYPE_MAP) {
		if (number.match(key)) {
			return value;
		}
	}

	return "";
}

function getLabelText(input) {
	var id = input.id;
	if (id) {
		var label = document.querySelector("label[for='" + id + "']");
		if (label) {
			return getVal(label.innerText);
		}
	}

	var parent = input.parentElement;
	if (parent) {
		var previous = parent.previousElementSibling;
		if (previous && previous.tagName.toLowerCase() === "label") {
			return getVal(previous.innerText);
		}
	}

	return "";
}

function getAddress(name, result) {
	var address = result.data.profile.bill;
	if (result.data.profile.ship && name.includes("ship")) {
		address = result.data.profile.ship;
	}

	return address;
}

function getAttr(input, attr) {
	var attribute = "";
	if (input) {
		attribute = getVal(input.getAttribute(attr));
	}

	return attribute;
}

function isDefaultMode(mode) {
	return mode === undefined || mode === "1"
}

function getGlobalEMerchant() {
	var html = document.getElementsByTagName("html")[0];
	if (html && html.innerHTML) {
		var m = html.innerHTML.match(GLOBAL_E_GET_MERCHANT_REGEX);
		if (m) {
			return m[1];
		}
	}
	return "https://webservices.global-e.com";
}
