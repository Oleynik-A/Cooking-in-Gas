const REGEX_NAME_FULL_NAME = new RegExp("^name|full.?name|your.?name|customer.?name|bill.?name|ship.?name" + "|name.*first.*last|firstandlastname", "i");
const REGEX_NAME_FIRST_NAME = new RegExp("first.*name|initials|fname|first$|given.*name", "i");
const REGEX_NAME_LAST_NAME = new RegExp("last.*name|lname|surname|last$|secondname|family.*name", "i");
const REGEX_NAME_ADDRESS_1 = new RegExp("^address$|address[_-]?line(one)?|address1|addr1|street", "i");
const REGEX_NAME_ADDRESS_2 = new RegExp("address[_-]?line(2|two)|address.?2|addr2|street.?(?:#|no|num|nr)|suite|unit", "i");
const REGEX_NAME_CITY = new RegExp("city|town", "i");
const REGEX_NAME_STATE = new RegExp("(?<!(united|hist|history).?)state|county|region|province", "i");
const REGEX_NAME_COUNTRY = new RegExp("country|countries", "i");
const REGEX_NAME_ZIP = new RegExp("zip|postal|post.*code|pcode", "i");
const REGEX_NAME_EMAIL = new RegExp("e.?mail", "i");
const REGEX_NAME_PHONE = new RegExp("phone|mobile|contact.?number|tel", "i");
const REGEX_NAME_CARD_NAME = new RegExp("card.?(?:holder|owner)|name.*(\\b)?on(\\b)?.*card", "i");
const REGEX_NAME_CARD_NUMBER = new RegExp("(add)?(?:card|cc|acct).?(?:number|#|no|num|field)|carn|credit.*?card.*?cnb", "i");
const REGEX_NAME_CARD_CVV = new RegExp("verification|card.?identification|security.?code|card.?code" + "|security.?value" + "|security.?number|card.?pin|c-v-v" + "|(cvn|cvv|cvc|csc|cvd|cid|ccv)(field)?" + "|\\bcid\\b", "i");
const REGEX_NAME_CARD_EXP_MONTH = new RegExp("exp.*mo|ccmonth|card.?month|addmonth", "i");
const REGEX_NAME_CARD_EXP_YEAR = new RegExp("(?:exp|payment|card).*(?:year|yr)", "i");
const REGEX_NAME_CARD_TYPE = new RegExp("(credit)?card.*type", "i");
const REGEX_NAME_CARD_EXP_DATE = new RegExp("expir|exp.*date|^expfield$", "i");
const REGEX_NAME_DISCORD_TAG = new RegExp("discord.*?(tag)?", "i");
const REGEX_NAME_TWITTER_HANDLE = new RegExp("twitter.*?handle", "i");
const REGEX_NAME_CHECKBOX = new RegExp("(order)?.*?terms" + "|consent.*?(checkbox)?", "i");
const REGEX_NAME_PASSWORD = new RegExp("^password$|^Password$", "i");
const REGEX_NAME_BIRTHDAY = new RegExp("^birthday$|^Birthday$|^birth-day$", "i");
var regexArray = {
	firstName: REGEX_NAME_FIRST_NAME,
	lastName: REGEX_NAME_LAST_NAME,
	email: REGEX_NAME_EMAIL,
	phoneNumber: REGEX_NAME_PHONE,
	address: REGEX_NAME_ADDRESS_1,
	address2: REGEX_NAME_ADDRESS_2,
	city: REGEX_NAME_CITY,
	zipcode: REGEX_NAME_ZIP,
	state: REGEX_NAME_STATE,
	country: REGEX_NAME_COUNTRY,
	cardholderName: REGEX_NAME_CARD_NAME,
	cardType: REGEX_NAME_CARD_TYPE,
	cardNumber: REGEX_NAME_CARD_NUMBER,
	expiryMonth: REGEX_NAME_CARD_EXP_MONTH,
	expiryYear: REGEX_NAME_CARD_EXP_YEAR,
	cvv: REGEX_NAME_CARD_CVV,
	password: REGEX_NAME_PASSWORD,
	birthday: REGEX_NAME_BIRTHDAY
};

function autofill_id(name, value) {
	if (document.getElementById(name)) {
		autofill(document.getElementById(name), value);
	}
}

function autoComplete(name, value) {
	document.querySelectorAll(`[autocomplete=${name}]`).forEach(function (element) {
		autofill(element, value);
	});
}

function autofill(element, value) {
	document.createEvent("HTMLEvents").initEvent('change', true, false);
	element.focus();
	element.value = value;
	element.dispatchEvent(document.createEvent("HTMLEvents"));
	element.blur();
}

function all_autofills(name, value) {
	autoComplete(name, value);
	autofill_name(name, value);
	autofill_id(name, value);
}

function autofill_name(name, value) {
	if (document.getElementsByName(name)[0]) {
		autofill(document.getElementsByName(name)[0], value);
	}
}


window.onload = () => {
	chrome.storage.local.get(['profiles', 'profileTasks', 'settings'], (data) => {
		let profilesData = data.profiles
		let profileTasks = data.profileTasks
		let settings = data.settings
		let profile
		for (var i = 0; i < profileTasks.length; i++) {
			if (profileTasks[i].Uses >= 1 || profileTasks[i].Uses == "&#8734") {
				profile = profilesData.find(profileObj => {
					return profileObj.profileName == profileTasks[i].profileName
				})
				break
			}
		}

		chrome.storage.sync.get("user", data => {
			if (data.user != "") {
				if (settings.enabled && profile) {
					// all_autofills('email', profile.email);
					// all_autofills('name', `${profile.firstName} ${profile.lastName}`);
					// all_autofills('fullName', `${profile.firstName} ${profile.lastName}`);
					// all_autofills('first-name', profile.firstName);
					// all_autofills('firstname', profile.firstName);
					// all_autofills('firstName', profile.firstName);
					// all_autofills('last-name', profile.lastName);
					// all_autofills('lastname', profile.lastName);
					// all_autofills('lastName', profile.lastName);
					// all_autofills('tel', profile.phoneNumber);
					// all_autofills('address-line1', `${profile.address}, ${profile.address2}`);
					// all_autofills('address-level2', profile.city);
					// all_autofills('city', profile.city);
					// all_autofills('state', profile.state);
					// all_autofills('address-level1', profile.state);
					// all_autofills('postal-code', profile.zipcode);
					// all_autofills('zipcode', profile.zipcode);
					// all_autofills('postcode', profile.zipcode);
					// all_autofills('post-code', profile.zipcode);
					// all_autofills('password', profile.password);
					// all_autofills('birthday', generateRandomBirthday());

					// checking saved profile data in this extension
					console.log(profile.password);
					console.log(generateRandomBirthday());

					// var elements = document.body.getElementsByTagName("input")

					// for (const key in regexArray) {
					// 	Array.from(elements).forEach(element => {
					// 		console.log(element)
					// 		let regExp = regexArray[key]
					// 		if (regExp.test(element.id) || regExp.test(element.className) || regExp.test(element.getAttribute('autocomplete')) || regExp.test(element.name)) {
					// 			console.log("passed")
					// 			element.value = profile[key];
					// 			all_autofills(`${key}`, profile[key]);
					// 		}
					// 	})
					// }

					autofill_all_attributes();

				}
			}
		})
	})
}


function autofill_all_attributes() {
	var elements = document.body.getElementsByTagName("input")

	for (const key in regexArray) {
		Array.from(elements).forEach(element => {
			console.log(element)
			let regExp = regexArray[key]
			if (regExp.test(element.id) || regExp.test(element.className) || regExp.test(element.getAttribute('autocomplete')) || regExp.test(element.name)) {
				console.log("passed")
				element.value = profile[key];
				all_autofills(`${key}`, profile[key]);
			}
		})
	}
}


function generateRandomBirthday() {
	let month = Math.ceil(12 * Math.random());
	let date = Math.ceil(31 * Math.random());
	let year = Math.ceil(119 * Math.random()) + 1900;
	if ((month % 2 == 0 && month <= 7) || (month % 2 == 1 && month > 7)) {
		date = (date > 30) ? 30 : date;
	}
	if (month == 2) {
		let maxFeb = (year % 4) ? 28 : 29;
		date = (date > maxFeb) ? maxFeb : date;
	}

	return ((date < 10) ? (`0${date}`) : (`${date}`))
		+ '/' + ((month < 10) ? (`0${month}`) : (`${month}`)) + '/'
		+ `${year}`;

}



// chrome.tabs.onUpdated.addListener(function (tabId, info) {
// 	if (info.status === 'complete') {
// 		chrome.tabs.executeScript({
// 			code: "document.documentElement.innerHTML" // or 'file: "getPagesSource.js"'
// 		}, function (result) {
// 			if (chrome.runtime.lastError) {
// 				console.error(chrome.runtime.lastError.message);
// 			} else {
// 				console.log(result)
// 			}
// 		});
// 	}
// });