

document.getElementById("autofillBtn").addEventListener("click", () => {
	window.open('autofill.html')
})
/*
document.getElementById("logout").addEventListener("click", () => {
	chrome.storage.sync.get('user', function (data) {
		if (data.user) {
			let email = data.user;
			$.post("https://cookingongas.io/token_manager/JRA/api_accountManager.php", { action: "logout", productName: "discord monitor & autofiller", eMail: email }, (data) => {
				chrome.browserAction.setPopup({ popup: "login.html" });
				chrome.storage.sync.set({ user: "" });
				chrome.runtime.sendMessage({ logout: true });
				window.close();
			});
		} else {
			chrome.browserAction.setPopup({ popup: "login.html" });
			window.close();
		}
	});
});
*/


function canUseProduct() {
	chrome.storage.sync.get('user', (data) => {
		if (data.user) {
			let email = data.user;
			$.post("https://cookingongas.io/token_manager/JRA/api_accountManager.php", { action: "canUseProduct", productName: "discord monitor & autofiller", eMail: email }, (data) => {
				if (data != "YES") {
					$.post("https://cookingongas.io/token_manager/JRA/api_accountManager.php", { action: "logout", productName: "discord monitor & autofiller", eMail: email }, (data) => { })
					chrome.storage.sync.set({ user: "" }, () => { })
					chrome.browserAction.setPopup({ popup: "login.html" });
					alert("your token has expired.");
					window.close();
				}
			});
		} else {
			chrome.browserAction.setPopup({ popup: "login.html" });
			window.close();
		}
	});
}
//canUseProduct();