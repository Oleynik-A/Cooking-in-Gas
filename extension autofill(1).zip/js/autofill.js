chrome.runtime.onMessage.addListener(function (message, sender) {
	if (!message.logout) return
	window.close()
})
/*
chrome.runtime.onMessage.addListener(async function (message, sender) {
	if (!message.success) return
	let profile = message.profile
	let allProfiles = JSON.parse(localStorage.getItem("profileTasks"))
	let newProfile = allProfiles.find(profileObj => {
		return profileObj.profileName == profile.profileName
	})
	newProfile.Uses = newProfile.Uses - 1
	localStorage.removeItem("profileTasks")
	localStorage.setItem("profileTasks", JSON.stringify(allProfiles))
	loadProfileTasks()
})
*/
document.getElementById("nav-tab").addEventListener('click', (event) => {
	onTabClick(event)
	return false
})

function onTabClick(event) {
	let activeTabs = document.querySelectorAll('.active')

	activeTabs.forEach(tab => {
		tab.className = tab.className.replace('active', '')
	})
	event.target.parentElement.className += ' active'
	document.getElementById(event.target.href.split('#')[1]).className += ' active'
}



// for matt I removed login page and login code 
// autofill code shouldnt run if user isnt logged in
// when user logs in this code below runs except its not test its their username
chrome.storage.sync.set({ "user": "test" }, () => { })

window.onload = loadProfiles()

function loadProfiles() {
	//let profilesArray = JSON.parse(localStorage.getItem("Profiles"))
	document.getElementById("load-profiles").options.length = 1
	document.getElementById("profile-select").options.length = 1
	chrome.storage.local.get("profiles", async data => {
		if (data.profiles) {
			data.profiles.forEach(profile => {
				addProfiles(profile.profileName)
			})
			//chrome.storage.local.set({ "profiles": profilesArray }, () => { })
		}
	})
}

document.getElementById("load-profiles").addEventListener('change', () => {

	if (document.getElementById("saveProfile").innerHTML == "ReSave") {
		document.getElementById("saveProfile").innerHTML = "Save"
		document.getElementById("saveProfile").style.width = "43%"
		document.getElementById("deleteProfile").style.display = "none"
	}

	let selectedProfileName = document.getElementById("load-profiles").value
	chrome.storage.local.get("profiles", async data => {
		let allProfiles = data.profiles
		let profile = allProfiles.find(profile => { return profile.profileName == selectedProfileName })

		/*
		let allProfiles = JSON.parse(localStorage.getItem("Profiles"))
		let profile = allProfiles.find(profile => { return profile.profileName == selectedProfileName })
		*/

		document.getElementById("profile_name").value = profile.profileName
		document.getElementById("first_name").value = profile.firstName
		document.getElementById("last_name").value = profile.lastName
		document.getElementById("email").value = profile.email
		document.getElementById("phone").value = profile.phoneNumber
		document.getElementById("address1").value = profile.address
		document.getElementById("address2").value = profile.address2
		document.getElementById("address3").value = profile.address3
		document.getElementById("city").value = profile.city
		document.getElementById("zip").value = profile.zipcode
		document.getElementById("state").value = profile.state
		document.getElementById("country").value = profile.country
		document.getElementById("cardName").value = profile.cardholderName
		document.getElementById("cardType").value = profile.cardType
		document.getElementById("num").value = profile.cardNumber
		document.getElementById("expM").value = profile.expiryMonth
		document.getElementById("expY").value = profile.expiryYear
		document.getElementById("CVV").value = profile.cvv
		document.getElementById("password").value = profile.password
		document.getElementById("saveProfile").innerHTML = "ReSave"
		document.getElementById("saveProfile").style.width = "21.5%"
		document.getElementById("deleteProfile").style.display = "inline-block"

		let profileBtn = document.getElementById("saveProfile")
		profileBtn.addEventListener("click", () => {
			if (profileBtn.innerHTML == "ReSave") {
				let profileIndex = allProfiles.indexOf(profile)
				let newProfile = allProfiles[profileIndex]

				newProfile.profileName = document.getElementById("profile_name").value
				newProfile.firstName = document.getElementById("first_name").value
				newProfile.lastName = document.getElementById("last_name").value
				newProfile.email = document.getElementById("email").value
				newProfile.phoneNumber = document.getElementById("phone").value
				newProfile.address = document.getElementById("address1").value
				newProfile.address2 = document.getElementById("address2").value
				newProfile.address3 = document.getElementById("address3").value
				newProfile.city = document.getElementById("city").value
				newProfile.zipcode = document.getElementById("zip").value
				newProfile.state = document.getElementById("state").value
				newProfile.country = document.getElementById("country").value
				newProfile.cardholderName = document.getElementById("cardName").value
				newProfile.cardType = document.getElementById("cardType").value
				newProfile.cardNumber = document.getElementById("num").value
				newProfile.expiryMonth = document.getElementById("expM").value
				newProfile.expiryYear = document.getElementById("expY").value
				newProfile.cvv = document.getElementById("CVV").value
				newProfile.password = document.getElementById("password").value

				chrome.storage.local.set({ profiles: allProfiles }, () => { })
				/*
				localStorage.removeItem("Profiles")
				localStorage.setItem("Profiles", JSON.stringify(allProfiles))
				*/

				document.getElementById("profile_name").value = ""
				document.getElementById("first_name").value = ""
				document.getElementById("last_name").value = ""
				document.getElementById("email").value = ""
				document.getElementById("phone").value = ""
				document.getElementById("address1").value = ""
				document.getElementById("address2").value = ""
				document.getElementById("address3").value = ""
				document.getElementById("city").value = ""
				document.getElementById("zip").value = ""
				document.getElementById("state").value = ""
				document.getElementById("country").value = ""
				document.getElementById("cardName").value = ""
				document.getElementById("cardType").value = ""
				document.getElementById("num").value = ""
				document.getElementById("expM").value = ""
				document.getElementById("expY").value = ""
				document.getElementById("CVV").value = ""
				document.getElementById("password").value = ""
				document.getElementById("saveProfile").innerHTML = "Save"
				document.getElementById("saveProfile").style.width = "43%"
				document.getElementById("deleteProfile").style.display = "none"
				loadProfiles()
				location.reload()
			}
		})
	})
})

function addProfiles(profileName) {
	let selectOpt = document.createElement('option')
	selectOpt.appendChild(document.createTextNode(profileName))
	selectOpt.value = profileName
	document.getElementById("load-profiles").append(selectOpt)
	let selectOpt2 = document.createElement('option')
	selectOpt2.appendChild(document.createTextNode(profileName))
	selectOpt2.value = profileName
	document.getElementById("profile-select").append(selectOpt2)
}

let profileBtn = document.getElementById("saveProfile")
profileBtn.addEventListener("click", () => {
	if (profileBtn.innerHTML == "Save") {
		let newProfile = {
			profileName: document.getElementById("profile_name").value,
			firstName: document.getElementById("first_name").value,
			lastName: document.getElementById("last_name").value,
			email: document.getElementById("email").value,
			phoneNumber: document.getElementById("phone").value,
			address: document.getElementById("address1").value,
			address2: document.getElementById("address2").value,
			address3: document.getElementById("address3").value,
			city: document.getElementById("city").value,
			country: document.getElementById("country").value,
			state: document.getElementById("state").value,
			zipcode: document.getElementById("zip").value,
			cardholderName: document.getElementById("cardName").value,
			cardType: document.getElementById("cardType").value,
			cardNumber: document.getElementById("num").value,
			expiryMonth: document.getElementById("expM").value,
			expiryYear: document.getElementById("expY").value,
			cvv: document.getElementById("CVV").value,
			password: document.getElementById("password")
		}
		document.getElementById("profile_name").value = ""
		document.getElementById("first_name").value = ""
		document.getElementById("last_name").value = ""
		document.getElementById("email").value = ""
		document.getElementById("phone").value = ""
		document.getElementById("address1").value = ""
		document.getElementById("address2").value = ""
		document.getElementById("address3").value = ""
		document.getElementById("city").value = ""
		document.getElementById("zip").value = ""
		document.getElementById("state").value = ""
		document.getElementById("country").value = ""
		document.getElementById("cardName").value = ""
		document.getElementById("cardType").value = ""
		document.getElementById("num").value = ""
		document.getElementById("expM").value = ""
		document.getElementById("expY").value = ""
		document.getElementById("CVV").value = ""
		document.getElementById("password") = ""

		chrome.storage.local.get("profiles", async data => {
			if (data.profiles) {
				data.profiles.push(newProfile)
				chrome.storage.local.set({ profiles: data.profiles }, () => { })
				loadProfiles()
			} else {
				chrome.storage.local.set({ profiles: [newProfile] }, () => { })
				loadProfiles()
			}
		})
		/*
		let allTasks
		allTasks = JSON.parse(localStorage.getItem("Profiles"))

		if (allTasks == null) {
			localStorage.setItem("Profiles", "[]")
			allTasks = JSON.parse(localStorage.getItem("Profiles"))
		}

		allTasks.push(newProfile)
		localStorage.setItem("Profiles", JSON.stringify(allTasks))

		loadProfiles()
		*/
	}
})

let deleteProfile = document.getElementById("deleteProfile")
deleteProfile.addEventListener('click', () => {
	if (confirm("Are you sure you want to delete?")) {
		let selectedProfileName = document.getElementById("profile_name").value
		chrome.storage.local.get("profiles", async data => {
			let profile = data.profiles.find(profile => { return profile.ProfileName == selectedProfileName })
			let profileIndex = data.profiles.indexOf(profile)
			data.profiles.splice(profileIndex, 1)
			chrome.storage.local.set({ profiles: data.profiles }, () => { })
			//loadProfileTasks()
		})
		/*
		let allProfiles = JSON.parse(localStorage.getItem("Profiles"))
		let profile = allProfiles.find(profile => { return profile.ProfileName == selectedProfileName })
		let profileIndex = allProfiles.indexOf(profile)
		allProfiles.splice(profileIndex, 1)
		localStorage.removeItem("Profiles")
		localStorage.setItem("Profiles", JSON.stringify(allProfiles))
		*/

		document.getElementById("profile_name").value = ""
		document.getElementById("first_name").value = ""
		document.getElementById("last_name").value = ""
		document.getElementById("email").value = ""
		document.getElementById("phone").value = ""
		document.getElementById("address1").value = ""
		document.getElementById("address2").value = ""
		document.getElementById("address3").value = ""
		document.getElementById("city").value = ""
		document.getElementById("zip").value = ""
		document.getElementById("state").value = ""
		document.getElementById("country").value = ""
		document.getElementById("cardName").value = ""
		document.getElementById("cardType").value = ""
		document.getElementById("num").value = ""
		document.getElementById("expM").value = ""
		document.getElementById("expY").value = ""
		document.getElementById("CVV").value = ""
		document.getElementById("password") = ""
		document.getElementById("saveProfile").innerHTML = "Save"
		document.getElementById("saveProfile").style.width = "43%"
		document.getElementById("deleteProfile").style.display = "none"
		loadProfiles()
		location.reload()
	}
})


window.onload = loadProfileTasks()



function loadProfileTasks() {
	//let tasksArray = JSON.parse(localStorage.getItem("profileTasks"))
	document.getElementById("profiles-table").tBodies[0].innerHTML = ""
	chrome.storage.local.get("profileTasks", data => {
		if (data.profileTasks) {
			data.profileTasks.forEach(Task => {
				addTaskToTable(Task)
			})
			//chrome.storage.local.set({ "profileTasks": tasksArray }, () => { })
		}
	})
}

function editTask(e) {
	/*
	let tasksArray = JSON.parse(localStorage.getItem("profileTasks"))
	let Task = tasksArray[clickedID]

	document.getElementById("profile-select").value = Task.profileName
	document.getElementById("profile-uses").value = Task.Uses
	document.getElementById("profile-add").innerHTML = "ReSave"
	*/
	let clickedID = Number(e.target.parentElement.id) - 1
	chrome.storage.local.get("profileTasks", data => {
		let Task = data.profileTasks[clickedID]
		document.getElementById("profile-select").value = Task.profileName
		document.getElementById("profile-uses").value = Task.Uses
		document.getElementById("profile-add").innerHTML = "ReSave"


		let addTaskBtn = document.getElementById("profile-add")
		addTaskBtn.addEventListener('click', () => {
			if (addTaskBtn.innerHTML == "ReSave") {
				Task.profileName = document.getElementById("profile-select").value
				if (document.getElementById("profile-uses").value == "") {
					Task.Uses = "&#8734"
				} else {
					Task.Uses = document.getElementById("profile-uses").value
				}
				chrome.storage.local.set({ profileTasks: data.profileTasks }, () => { })
				document.getElementById("profile-select").value = ""
				document.getElementById("profile-uses").value = ""
				document.getElementById("profile-add").innerHTML = "Save"
				loadProfileTasks()
				location.reload()
				/*
				localStorage.removeItem("profileTasks")
				localStorage.setItem("profileTasks", JSON.stringify(tasksArray))
				document.getElementById("profile-select").value = ""
				document.getElementById("profile-uses").value = ""
				document.getElementById("profile-add").innerHTML = "Save"
				loadProfileTasks()
				location.reload()
				*/
			}
		})
	})
}
function removeTask(e) {
	let clickedID = Number(e.target.parentElement.id) - 1
	chrome.storage.local.get("profileTasks", async data => {
		data.profileTasks.splice(clickedID, 1)
		chrome.storage.local.set({ profileTasks: data.profileTasks }, () => { })
		loadProfileTasks()
	})
	/*
	let tasksArray = JSON.parse(localStorage.getItem("profileTasks"))
	tasksArray.splice(clickedID, 1)
	localStorage.removeItem("profileTasks")
	localStorage.setItem("profileTasks", JSON.stringify(tasksArray))
	loadProfileTasks()
	*/
}

function addTaskToTable(Task) {
	let table = document.getElementById("profiles-table")
	let rows_count = table.rows.length
	let tableRow = document.createElement('tr')
	let index = document.createElement('td')
	let profile = document.createElement('td')
	let uses = document.createElement('td')

	index.innerHTML = rows_count
	profile.innerHTML = Task.profileName
	uses.innerHTML = Task.Uses

	chrome.storage.local.get("profileTasks", async data => {
		data.profileTasks[rows_count - 1].Index = rows_count
		chrome.storage.local.set({ profileTasks: data.profileTasks }, () => { })
	})

	/*
	let all_tasks = JSON.parse(localStorage.getItem("profileTasks"))
	localStorage.removeItem("profileTasks")
	all_tasks[rows_count - 1].Index = rows_count
	localStorage.setItem("profileTasks", JSON.stringify(all_tasks))
	*/

	let editBtn = document.createElement('button')
	let removeBtn = document.createElement('button')

	editBtn.classList.add('editBtn')
	removeBtn.classList.add('removeBtn')
	removeBtn.id = rows_count
	editBtn.id = rows_count
	editBtn.innerHTML = '<img class="actions-img" src="./images/edit-img.png" />'
	removeBtn.innerHTML = '<img class="actions-img" src="./images/delete-img.png" />'


	editBtn.addEventListener("click", (e) => {
		editTask(e)
	});

	removeBtn.addEventListener("click", (e) => {
		removeTask(e)
	});

	let actionsTd = document.createElement("td")

	actionsTd.appendChild(editBtn)
	actionsTd.appendChild(removeBtn)
	tableRow.appendChild(index)
	tableRow.appendChild(profile)
	tableRow.appendChild(uses)
	tableRow.append(actionsTd)
	table.tBodies[0].appendChild(tableRow)
}

let addTaskBtn = document.getElementById("profile-add")

addTaskBtn.addEventListener('click', () => {
	if (addTaskBtn.innerHTML == "Add") {
		let index = document.getElementById("profiles-table").rows.length
		let profile = document.getElementById("profile-select").value
		let uses = document.getElementById("profile-uses").value

		if (uses == "") {
			uses = "&#8734"
		} else {
			uses = Number(uses)
		}

		let newTask = {
			"Index": index,
			"profileName": profile,
			"Uses": uses
		}

		chrome.storage.local.get("profileTasks", async data => {
			if (data.profileTasks) {
				data.profileTasks.push(newTask)
				chrome.storage.local.set({ profileTasks: data.profileTasks }, () => { })
				loadProfileTasks()
			} else {
				chrome.storage.local.set({ profileTasks: [newTask] }, () => { })
				loadProfileTasks()
			}
		})
		/*
		let allTasks
		allTasks = JSON.parse(localStorage.getItem("profileTasks"))

		if (allTasks == null) {
			localStorage.setItem("profileTasks", "[]")
			allTasks = JSON.parse(localStorage.getItem("profileTasks"))
		}
		let newTask = {
			"Index": index,
			"profileName": profile,
			"Uses": uses
		}
		allTasks.push(newTask)
		localStorage.setItem("profileTasks", JSON.stringify(allTasks))
		loadProfileTasks()
		*/
	}
})





window.onload = loadSettings()

function loadSettings() {
	chrome.storage.local.get('settings', (data) => {
		let savedSettings = data.settings
		if (savedSettings) {
			document.getElementById("enable-checkbox").checked = savedSettings.enabled
			document.getElementById("typing-checkbox").checked = savedSettings.simulateTyping
			document.getElementById("steps-checkbox").checked = savedSettings.shopify.processCheckoutSteps
			document.getElementById("complete-checkbox").checked = savedSettings.shopify.completeCheckout
			document.getElementById("payment-checkbox").checked = savedSettings.supreme.processPayment
			document.getElementById("cyber-checkbox").checked = savedSettings.cyber.buyNow
			document.getElementById("hawk-checkbox").checked = savedSettings.hawk.buyNow;
			document.getElementById("enable-checkbox").disabled = true
			document.getElementById("typing-checkbox").disabled = true
			document.getElementById("steps-checkbox").disabled = true
			document.getElementById("complete-checkbox").disabled = true
			document.getElementById("payment-checkbox").disabled = true
			document.getElementById("cyber-checkbox").disabled = true
			document.getElementById("hawk-checkbox").disabled = true
			document.getElementById("saveSettings").innerHTML = "Reset"
		}
	})
}

let saveBtn = document.getElementById("saveSettings")
saveBtn.addEventListener("click", () => {
	if (saveBtn.innerHTML == "Save") {
		let enable = document.getElementById("enable-checkbox").checked
		let typing = document.getElementById("typing-checkbox").checked
		let process_checkout = document.getElementById("steps-checkbox").checked
		let complete = document.getElementById("complete-checkbox").checked
		let process_payment = document.getElementById("payment-checkbox").checked
		let cyberBuy = document.getElementById("cyber-checkbox").checked
		let hawkBuy = document.getElementById("hawk-checkbox").checked
		let settings = {
			enabled: enable,
			simulateTyping: typing,
			supreme: {
				processPayment: process_payment
			},
			shopify: {
				processCheckoutSteps: process_checkout,
				completeCheckout: complete
			},
			cyber: {
				buyNow: cyberBuy
			},
			hawk: {
				buyNow: hawkBuy
			}
		}
		chrome.storage.local.set({ 'settings': settings }, () => { })
		saveBtn.innerHTML = "Reset"
		loadSettings()
	} else if (saveBtn.innerHTML == "Reset") {
		document.getElementById("enable-checkbox").checked = false
		document.getElementById("typing-checkbox").checked = false
		document.getElementById("steps-checkbox").checked = false
		document.getElementById("complete-checkbox").checked = false
		document.getElementById("payment-checkbox").checked = false
		document.getElementById("cyber-checkbox").checked = false
		document.getElementById("hawk-checkbox").checked = false
		document.getElementById("enable-checkbox").disabled = false
		document.getElementById("typing-checkbox").disabled = false
		document.getElementById("steps-checkbox").disabled = false
		document.getElementById("complete-checkbox").disabled = false
		document.getElementById("payment-checkbox").disabled = false
		document.getElementById("cyber-checkbox").disabled = false
		document.getElementById("hawk-checkbox").disabled = false
		document.getElementById("saveSettings").innerHTML = "Save"
		chrome.storage.local.set({ 'settings': null }, () => { })
	}
});



// document.getElementById('randomBirthdayBtn').addEventListener('click', () => {
// 	let day = generateRandomBirthday();
// 	var randomDay='';
// 	randomDay = ((day.date<10)?(`0${day.date}`):(`${day.date}`))
// 	 	+ '/' + ((day.month<10)?(`0${day.month}`):(`${day.month}`)) + '/'
// 	 	+ `${day.year}`;
// 	document.getElementById('randomBirthdayInput').value = randomDay;
// });
