chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
	if (request.action === 'check') {
		chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
			chrome.tabs.sendMessage(tabs[0].id, { action: 'check' })
		})
	}
})
/*
function logResponse(responseDetails) {
	let headers = responseDetails.requestHeaders
	let authHeader = headers.find(obj => {return obj.name == 'Authorization'})
  	let token = authHeader.value
  	chrome.storage.local.set({'token': token})
}

chrome.webRequest.onBeforeSendHeaders.addListener(
  logResponse,{
    urls: ["https://discordapp.com/api/v6/science"]
  }, ["requestHeaders"]
)
*/



chrome.tabs.onUpdated.addListener(function (tabId, info) {
	if (info.status === 'complete') {
		chrome.tabs.executeScript({
			code: "document.documentElement.innerHTML" // or 'file: "getPagesSource.js"'
		}, function (result) {
			if (chrome.runtime.lastError) {
				// console.error(chrome.runtime.lastError.message);
			} else {
				console.log(result)
			}
		});
	}
});