
function autofill_id(name, value) {
	if (document.getElementById(name)) {
		autofill(document.getElementById(name), value);
	}
}

function autoComplete(name, value) {
	document.querySelectorAll(`[autocomplete=${name}]`).forEach(function (element) {
		autofill(element, value);
	});
}

function autofill(element, value) {
	processInputWithDispatchEvent(element, value);
	// document.createEvent("HTMLEvents").initEvent('change', true, false);
	// element.focus();
	// element.value = value;
	// element.dispatchEvent(document.createEvent("HTMLEvents"));
	// element.blur();
}

function all_autofills(name, value) {
	autoComplete(name, value);
	autofill_name(name, value);
	autofill_id(name, value);
	autofill_placeHolder(name, value);
}

function autofill_name(name, value) {
	if (document.getElementsByName(name)[0]) {
		autofill(document.getElementsByName(name)[0], value);
	}
}

function autofill_placeHolder(name, value) {
	document.querySelectorAll(`[placeholder=${name}]`).forEach(function (element) {
		autofill(element, value);
	});
}
function autoFillData() {
	chrome.storage.local.get(['profiles', 'profileTasks', 'settings'], (data) => {
		let profilesData = data.profiles
		let profileTasks = data.profileTasks
		let settings = data.settings
		let profile
		if (!profileTasks) {
			console.log('please add profile in COS extension');
			return;
		}
		for (var i = 0; i < profileTasks.length; i++) {
			if (profileTasks[i].Uses >= 1 || profileTasks[i].Uses == "&#8734") {
				profile = profilesData.find(profileObj => {
					return profileObj.profileName == profileTasks[i].profileName
				})
				break
			}
		}
		profile.birthday = generateRandomBirthday();
		chrome.storage.sync.get("user", data => {
			if (data.user != "") {
				if (settings.enabled && profile) {
					// all_autofills('email', profile.email);
					// all_autofills('name', `${profile.firstName} ${profile.lastName}`);
					// all_autofills('fullName', `${profile.firstName} ${profile.lastName}`);
					// all_autofills('first-name', profile.firstName);
					// all_autofills('firstname', profile.firstName);
					// all_autofills('firstName', profile.firstName);
					// all_autofills('last-name', profile.lastName);
					// all_autofills('lastname', profile.lastName);
					// all_autofills('lastName', profile.lastName);
					// all_autofills('tel', profile.phoneNumber);
					// all_autofills('address-line1', `${profile.address}, ${profile.address2}`);
					// all_autofills('address-level2', profile.city);
					// all_autofills('city', profile.city);
					// all_autofills('state', profile.state);
					// all_autofills('address-level1', profile.state);
					// all_autofills('postal-code', profile.zipcode);
					// all_autofills('zipcode', profile.zipcode);
					// all_autofills('postcode', profile.zipcode);
					// all_autofills('post-code', profile.zipcode);
					// all_autofills('password', profile.password);
					// all_autofills('birthday', generateRandomBirthday());
					// console.log(profile.lastName)
					// console.log(profile.birthday)
					autofill_all_attributes(profile);

				}
			}
		})
	})
}

var isQueueStarted = false
var actions = []

async function startQueue() {
	if (isQueueStarted) return;
	isQueueStarted = true
	var action = null
	while (action = actions.shift()) {
		await action();
	}
	isQueueStarted = false
}
var globalTimerId = null

function debounce() {
	actions.push(async () => {
		if (globalTimerId) {
			clearTimeout(globalTimerId)
			globalTimerId = null;
		}
		globalTimerId = setTimeout(() => {

			chrome.extension.sendMessage({ msgType: "data" }, result => {
				autoFillData()
			})
			globalTimerId = null;
		}, 500)
	})

	startQueue();
}
MutationObserver = window.MutationObserver || window.WebKitMutationObserver;

var observer = new MutationObserver(function (mutations, observer) {
	// fired when a mutation occurs
	// console.log(mutations, observer);
	debounce()
	// ...
});

function catchDomChange(_document) {

	// define what element should be observed by the observer
	// and what types of mutations trigger the callback
	observer.observe(_document, {
		subtree: true,
		childList: true,
		// attributes: true
		//...
	});
}

catchDomChange(document)

function autofill_all_attributes(profile) {
	var elements = document.getElementsByTagName("input")
	var buttons = document.getElementsByTagName("button");

	for (const key in regexArray) {
		let regExp = regexArray[key]
		if (key == "button") {
			Array.from(buttons).forEach(element => {
				if (regExp.test(element.className)) {
					console.log(element)
					setTimeout(() => {
						element.click();
					}, 1000)
				}
			})
		}
		Array.from(elements).forEach(element => {

			if (element.type == "checkbox") {
				if (regExp.test(element.name)) {
					console.log(element)
					setTimeout(() => {
						element.setAttribute("checked", "")
					}, 100)
				}
			}

			if (/^Day|^day$/.test(element.placeholder)) {
				element.value = profile.birthday.date;
				console.log(element, `matched: ${profile.birthday.date}`)
			} else if (/^Month|^month$/.test(element.placeholder)) {
				element.value = profile.birthday.month;
				console.log(element, `matched: ${profile.birthday.month}`)
			} else if (/^Year|^year$/.test(element.placeholder)) {
				element.value = profile.birthday.year;
				console.log(element, `matched: ${profile.birthday.year}`)
			} else if (/^Name|^name$/.test(element.name)) {
				element.value = `${profile.firstName}${profile.lastName}`
				console.log(element.value, "name input is catched")
			}
			// if (element.type == "submit" && /Sign Up/.test(element.name)) {
			// 	setTimeout(() => {
			// 		element.click();
			// 	}, 1000)
			// }  
			if (regExp.test(element.id) || regExp.test(element.className) || regExp.test(element.getAttribute('autocomplete')) || regExp.test(element.name) || regExp.test(element.type) || regExp.test(element.placeholder)) {
				element.value = profile[key];
				// all_autofills(`${key}`, profile[key]);
				// console.log(element, `matched: ${key},  ${profile[key]}`)
			}
		})
	}
}


function generateRandomBirthday() {
	let month = Math.ceil(12 * Math.random());
	let date = Math.ceil(31 * Math.random());
	let year = Math.ceil(119 * Math.random()) + 1900;
	if ((month % 2 == 0 && month <= 7) || (month % 2 == 1 && month > 7)) {
		date = (date > 30) ? 30 : date;
	}
	if (month == 2) {
		let maxFeb = (year % 4) ? 28 : 29;
		date = (date > maxFeb) ? maxFeb : date;
	}
	date = (date<10)?(`0${date}`):(`${date}`);
	month = (month<10)?(`0${month}`):(`${month}`);
	return { date, month, year }
}
