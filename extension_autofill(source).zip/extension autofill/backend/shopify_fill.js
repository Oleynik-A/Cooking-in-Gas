function typeValue(element, value, i) {
	if (i < value.length) {
		element.value += value.charAt(i);
		element.dispatchEvent(new Event('change'));
		setTimeout(() => {
			i++;
			typeValue(element, value, i);
		}, 10);
	}
}

function autofillInput(id, value, select = false) {
	let element = document.querySelector(id)
	if (element) {
		element.focus();
		if (settings.typeValue && !select) {
			typeValue(element, value, 0);
		} else {
			element.value = value;
			element.dispatchEvent(new Event('change'));
		}
		element.blur();
	}
}

let settings
window.onload = () => {
	chrome.storage.local.get(['profiles', 'profileTasks', 'settings'], (data) => {
		let profilesData = data.profiles
		let profileTasks = data.profileTasks
		settings = data.settings
		let profile
		for (var i = 0; i < profileTasks.length; i++) {
			if (profileTasks[i].Uses >= 1 || profileTasks[i].Uses == "&#8734") {
				profile = profilesData.find(profileObj => {
					return profileObj.profileName == profileTasks[i].profileName
				})
				break
			}
		}
		chrome.storage.sync.get("user", data => {
			if (data.user != "") {
				if (settings.enabled && profile) {
					if (document.querySelector('[data-step]').dataset.step == 'shipping_method') {
						if (settings.shopify.processCheckoutSteps) {
							document.querySelector('.step__footer__continue-btn').click()
						}
					} else if (document.querySelector('[data-step]').dataset.step == 'contact_information') {
						let fields = {
							'[name="checkout[email_or_phone]"]': profile.email,
							'[name="checkout[email]"]': profile.email,
							'#checkout_email': profile.email,
							'#checkout_email_or_phone': profile.email,
							'#checkout_shipping_address_first_name': profile.firstName,
							'#checkout_shipping_address_last_name': profile.lastName,
							'#checkout_shipping_address_address1': profile.address,
							'#checkout_shipping_address_address2': profile.address2,
							'#checkout_shipping_address_city': profile.city,
							'#checkout_shipping_address_zip': profile.zipcode,
							'#checkout_shipping_address_phone': profile.phoneNumber,
							'#checkout_billing_address_first_name': profile.firstName,
							'#checkout_billing_address_last_name': profile.lastName,
							'#checkout_billing_address_address1': profile.address,
							'#checkout_billing_address_address2': profile.address2,
							'#checkout_billing_address_city': profile.city,
							'#checkout_billing_address_zip': profile.zipcode,
							'#checkout_billing_address_phone': profile.phoneNumber
						}

						Object.keys(fields).forEach(id => {
							autofillInput(id, fields[id]);
						});

						autofillInput('#checkout_shipping_address_country', profile.country, true);
						autofillInput('#checkout_shipping_address_province', profile.state, true);

						autofillInput('#checkout_billing_address_country', profile.country, true);
						autofillInput('#checkout_billing_address_province', profile.state, true);

						if (settings.shopify.processCheckoutSteps) {
							if (!(document.getElementById('g-recaptcha'))) {
								document.querySelector('.step__footer__continue-btn').click()
							}
						}
					}
				}
			}
		})
	})
}


chrome.extension.onMessage.addListener((request, sender, sendResponse) => {
	if (settings.shopify.completeCheckout && request.action === 'check') {
		let completeCheckout = setTimeout(() => {
			document.querySelector('.step__footer__continue-btn').click()
			clearTimeout(completeCheckout);
		}, 1000)
		/*
		let waitForCheckout = setInterval(()=> {
			console.log('waiting for checkout shopify/title includes thank you')
			if (document.querySelectorAll("title")) {
				if (document.querySelectorAll("title").innerText.includes("Thank you")) {
					chrome.runtime.sendMessage({ 
						success: true, 
						profile: profile 
		          	});
					clearInterval(waitForCheckout)
				}
			}
			
		}, 1000)*/
	}
});
