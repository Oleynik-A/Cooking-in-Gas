
chrome.storage.sync.get("user", data => {
	if (data.user != "") {
		main()
	}
})


function main() {
	chrome.storage.local.get(['profiles', 'profileTasks', 'settings'], (data) => {
		let profilesData = data.profiles
		let profileTasks = data.profileTasks
		let settings = data.settings
		let profile
		for (var i = 0; i < profileTasks.length; i++) {
			if (profileTasks[i].Uses >= 1 || profileTasks[i].Uses == "&#8734") {
				profile = profilesData.find(profileObj => {
					return profileObj.profileName == profileTasks[i].profileName
				})
				break
			}
		}
		if (settings.enabled && profile) {
			let shopify_order = document.getElementsByClassName('os-order-number')[0]
			console.log(shopify_order)
			if (shopify_order) {
				if (shopify_order.innerText.includes("Order #")) {
					console.log('found the order # = successful purchase')
					chrome.storage.local.get("profileTasks", async data => {
						console.log(profile)
						let allTasks = data.profileTasks
						let newProfile = allTasks.find(profileObj => {
							return profileObj.profileName == profile.profileName
						})
						newProfile.Uses = newProfile.Uses - 1
						chrome.storage.local.set({ profileTasks: allTasks }, () => { })
					})
					/*
					chrome.runtime.sendMessage({ 
						success: true, 
						profile: profile 
					})
					*/
				}
			}
		}
	})
}
