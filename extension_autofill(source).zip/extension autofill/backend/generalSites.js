function autofill_id(name, value) {
	if (document.getElementById(name)) {
		autofill(document.getElementById(name), value);
	}
}

function autoComplete(name, value) {
	document.querySelectorAll(`[autocomplete=${name}]`).forEach(function (element) {
		autofill(element, value);
	});
}

function autofill(element, value) {
	document.createEvent("HTMLEvents").initEvent('change', true, false);
	element.focus();
	element.value = value;
	element.dispatchEvent(document.createEvent("HTMLEvents"));
	element.blur();
}

function all_autofills(name, value) {
	autoComplete(name, value);
	autofill_name(name, value);
	autofill_id(name, value);
}

function autofill_name(name, value) {
	if (document.getElementsByName(name)[0]) {
		autofill(document.getElementsByName(name)[0], value);
	}
}


window.onload = () => {
	chrome.storage.local.get(['profiles', 'profileTasks', 'settings'], (data) => {
		let profilesData = data.profiles
		let profileTasks = data.profileTasks
		let settings = data.settings
		let profile
		for (var i = 0; i < profileTasks.length; i++) {
			if (profileTasks[i].Uses >= 1 || profileTasks[i].Uses == "&#8734") {
				profile = profilesData.find(profileObj => {
					return profileObj.profileName == profileTasks[i].profileName
				})
				break
			}
		}

		chrome.storage.sync.get("user", data => {
			if (data.user != "") {
				if (settings.enabled && profile) {
					all_autofills('email', profile.email);
					all_autofills('name', `${profile.firstName} ${profile.lastName}`);
					all_autofills('fullName', `${profile.firstName} ${profile.lastName}`);
					all_autofills('first-name', profile.firstName);
					all_autofills('firstname', profile.firstName);
					all_autofills('firstName', profile.firstName);
					all_autofills('last-name', profile.lastName);
					all_autofills('lastname', profile.lastName);
					all_autofills('lastName', profile.lastName);
					all_autofills('tel', profile.phoneNumber);
					all_autofills('address-line1', `${profile.address}, ${profile.address2}`);
					all_autofills('address-level2', profile.city);
					all_autofills('city', profile.city);
					all_autofills('state', profile.state);
					all_autofills('address-level1', profile.state);
					all_autofills('postal-code', profile.zipcode);
					all_autofills('zipcode', profile.zipcode);
					all_autofills('postcode', profile.zipcode);
					all_autofills('post-code', profile.zipcode);
				}
			}
		})
	})
}