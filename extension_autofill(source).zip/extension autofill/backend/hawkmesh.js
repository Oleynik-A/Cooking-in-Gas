window.onload = () => {
	chrome.storage.local.get(['profiles', 'profileTasks', 'settings'], (data) => {
		let profilesData = data.profiles
		let profileTasks = data.profileTasks
		let settings = data.settings
		let profile
		for (var i = 0; i < profileTasks.length; i++) {
			if (profileTasks[i].Uses >= 1 || profileTasks[i].Uses == "&#8734") {
				profile = profilesData.find(profileObj => {
					return profileObj.profileName == profileTasks[i].profileName
				})
				break
			}
		}
		chrome.storage.sync.get("user", data => {
			if (data.user != "") {
				if (settings.hawk.buyNow) { //&& profile not added since autofill isnt added yet
					let purchaseBtn = document.getElementsByClassName('btn btn-lg text-light idekhello')[0]
					if (!purchaseBtn.innerText.includes("Sold out")) {
						purchaseBtn.click()
					} else {
						console.log('sold out')
					}
				}
			}
		})
	})
}