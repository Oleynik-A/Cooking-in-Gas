// chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
// 	if (request.action === 'check') {
// 		chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
// 			chrome.tabs.sendMessage(tabs[0].id, { action: 'check' })
// 		})
// 	}
// })
chrome.extension.onMessage.addListener(function (request, sender, sendResponse) {
	sendResponse({resut: "sfsdf"})
})
/*
function logResponse(responseDetails) {
	let headers = responseDetails.requestHeaders
	let authHeader = headers.find(obj => {return obj.name == 'Authorization'})
  	let token = authHeader.value
  	chrome.storage.local.set({'token': token})
}

chrome.webRequest.onBeforeSendHeaders.addListener(
  logResponse,{
    urls: ["https://discordapp.com/api/v6/science"]
  }, ["requestHeaders"]
)
*/

// chrome.tabs.query({url: "https://*/*"}, function(tab) {
//    // reload tab with one of the methods from linked answer
//    chrome.tabs.reload(tab[0].id) 
// })