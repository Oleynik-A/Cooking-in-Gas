function autofillInput(name, value) {
	if (document.getElementsByName(name)[0]) {
		document.getElementsByName(name)[0].focus()
		document.getElementsByName(name)[0].value = value
		document.getElementsByName(name)[0].dispatchEvent(new Event('change'))
		document.getElementsByName(name)[0].blur()
	}
}

window.onload = () => {
	chrome.storage.local.get(['profiles', 'profileTasks', 'settings'], (data) => {
		let profilesData = data.profiles
		let profileTasks = data.profileTasks
		let settings = data.settings
		let profile
		if (!profileTasks) {
			console.log('please add profile in COS extension');
			return;
		}
		for (var i = 0; i < profileTasks.length; i++) {
			if (profileTasks[i].Uses >= 1 || profileTasks[i].Uses == "&#8734") {
				profile = profilesData.find(profileObj => {
					return profileObj.profileName == profileTasks[i].profileName
				})
				break
			}
		}

		chrome.storage.sync.get("user", data => {
			if (data.user != "") {
				if (settings.enabled && profile) {
					let fields = {
						'cardnumber': profile.cardNumber,
						'exp-date': `${profile.expiryMonth} / ${profile.expiryYear.slice(-2)}`,
						'cvc': profile.cvv,
						'postal': profile.zipcode
					}

					Object.keys(fields).forEach(id => {
						autofillInput(id, fields[id])
					});
				}
			}
		})
	})
}