function typeValue(element, value, i) {
	if (i < value.length) {
		element.value += value.charAt(i);
		element.dispatchEvent(new Event('change'));
		setTimeout(() => {
			i++;
			typeValue(element, value, i);
		}, 10);
	}
}

function autofillInput(id, value) {
	if (document.getElementById(id)) {
		document.getElementById(id).focus();
		if (settings.typeValue && !select) {
			typeValue(document.getElementById(id), value, 0);
		} else {
			document.getElementById(id).value = value;
			document.getElementById(id).dispatchEvent(new Event('change'));
		}
		document.getElementById(id).blur();
	}
}

let settings
window.onload = () => {
	chrome.storage.local.get(['profiles', 'profileTasks', 'settings'], (data) => {
		let profilesData = data.profiles
		let profileTasks = data.profileTasks
		settings = data.settings
		let profile
		for (var i = 0; i < profileTasks.length; i++) {
			if (profileTasks[i].Uses >= 1 || profileTasks[i].Uses == "&#8734") {
				profile = profilesData.find(profileObj => {
					return profileObj.profileName == profileTasks[i].profileName
				})
				break
			}
		}
		chrome.storage.sync.get("user", data => {
			if (data.user != "") {
				if (settings.enabled && profile) {
					let fields = {
						'number': profile.cardNumber,
						'name': profile.cardholderName,
						'expiry': `${profile.expiryMonth}/${profile.expiryYear}`,
						'verification_value': profile.cvv,
					}
					Object.keys(fields).forEach(id => {
						autofillInput(id, fields[id]);
					});
					chrome.runtime.sendMessage({ action: 'check' });
				}
			}
		})
	});
}
