window.onload = () => {
	chrome.storage.local.get(['profiles', 'profileTasks', 'settings'], (data) => {
		let profilesData = data.profiles
		let profileTasks = data.profileTasks
		let settings = data.settings
		let profile
		for (var i = 0; i < profileTasks.length; i++) {
			if (profileTasks[i].Uses >= 1 || profileTasks[i].Uses == "&#8734") {
				profile = profilesData.find(profileObj => {
					return profileObj.profileName == profileTasks[i].profileName
				})
				break
			}
		}
		chrome.storage.sync.get("user", data => {
			if (data.user != "") {
				if (settings.cyber.buyNow) { //&& profile not added since autofill isnt added yet
					let purchaseBtn = document.getElementById("purchase-button")
					if (!purchaseBtn.innerText.includes("Sold Out")) {
						purchaseBtn.click()
						document.getElementById("loader").style.display = "none"
						sleep(1000)
						document.getElementById('form-actions-button').click()
					} else {
						console.log('sold out')
					}
				}
			}
		})
	})
}
function sleep(ms) {
	return new Promise(resolve => setTimeout(resolve, ms));
}