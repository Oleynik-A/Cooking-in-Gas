function check(name, index = 0) {
	let element = document.getElementsByName(name)[index];
	if (element) {
		let event = document.createEvent("HTMLEvents");
		event.initEvent('change', true, false);
		element.checked = true;
		element.dispatchEvent(event);
	}
}

function typeValue(element, value, i) {
	if (i < value.length) {
		element.value += value.charAt(i);
		element.dispatchEvent(new Event('change'));
		setTimeout(() => {
			i++;
			typeValue(element, value, i);
		}, 10);
	}
}

function country_short(country) {
	let countries = {
		"united kingdom": "GB",
		"northern ireland": "NB",
		"united states": "USA",
		"canada": "CANADA",
		"austria": "AT",
		"belarus": "BY",
		"belgium": "BE",
		"bulgaria": "BG",
		"croatia": "HR",
		"czech republic": "CZ",
		"denmark": "DK",
		"estonia": "EE",
		"finland": "FI",
		"france": "FR",
		"germany": "DE",
		"greece": "GR",
		"hungary": "HU",
		"iceland": "IS",
		"ireland": "IE",
		"italy": "IT",
		"latvia": "LV",
		"lithuania": "LT",
		"luxembourg": "LU",
		"monaco": "MC",
		"netherlands": "NL",
		"norway": "NO",
		"poland": "PL",
		"portugal": "PT",
		"romania": "RO",
		"russia": "RU",
		"slovakia": "SK",
		"slovenia": "SI",
		"spain": "ES",
		"sweden": "SE",
		"switzerland": "CH",
		"turkey": "TR",
	}

	return countries[country.toLowerCase()];
}

function autofillInput(id, value, select = false) {
	let element = document.getElementById(id);
	if (element) {
		element.focus();
		if (settings.typeValue && !select) {
			typeValue(element, value, 0);
		} else {
			element.value = value;
			element.dispatchEvent(new Event('change'));
		}
		element.blur();
	}
}

let settings
window.onload = () => {
	chrome.storage.local.get(['profiles', 'profileTasks', 'settings'], (data) => {
		let profilesData = data.profiles
		let profileTasks = data.profileTasks
		settings = data.settings
		let profile
		for (var i = 0; i < profileTasks.length; i++) {
			if (profileTasks[i].Uses >= 1 || profileTasks[i].Uses == "&#8734") {
				profile = profilesData.find(profileObj => {
					return profileObj.profileName == profileTasks[i].profileName
				})
				break
			}
		}

		chrome.storage.sync.get("user", data => {
			if (data.user != "") {

				if (settings.enabled && profile) {
					let fields = {
						'order_billing_name': `${profile.firstName} ${profile.lastName}`,
						'order_email': profile.email,
						'order_tel': profile.phoneNumber,
						'bo': profile.address,
						'oba3': profile.address2,
						'order_billing_address_3': profile.address3,
						'order_billing_city': profile.city,
						'order_billing_zip': profile.zipcode,
						'cnb': profile.cardNumber,
						'rnsnckrn': profile.cardNumber,
						'vval': profile.cvv,
						'orcer': profile.cvv,
					}
					Object.keys(fields).forEach(id => {
						autofillInput(id, fields[id]);
					});
					autofillInput('order_billing_country', country_short(profile.country), true);
					autofillInput('order_billing_state', profile.state, true);
					autofillInput('credit_card_type', profile.cardType, true);
					autofillInput('credit_card_month', profile.expiryMonth, true);
					autofillInput('credit_card_year', profile.expiryYear, true);
					document.getElementsByClassName('icheckbox_minimal')[1].click();
					document.querySelector('.terms .icheckbox_minimal').classList.add('checked');
					if (settings.supreme.processPayment) {
						document.querySelector('.button, .checkout').click()
						//add code that remves 1 use from profile
						let waitForCheckout = setInterval(() => {
							if (document.getElementById("confirmation")) {
								if (document.getElementById("confirmation").innerText.includes("Your order has been successfully submitted")) {
									chrome.runtime.sendMessage({
										success: true,
										profile: profile
									});
									clearInterval(waitForCheckout)
								}
							}
						}, 1000)

					}
				}
			}
		})
	});
}